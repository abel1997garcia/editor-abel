# Contexto de Abel para la rutina diaria (cada archivo empieza por «# ARCHIVO:»)

---

# ARCHIVO: 00-avatar-operativo.md

# 00 · Mi marca: qué digo, a quién y desde dónde (18/10/2026)

> **FUENTE ÚNICA: esta página manda para cada reel, guion viral, carrusel, título, descripción, ficha de YouTube y story.** El nicho viejo de marca personal (emprendedores, agenda) está archivado en `_ARCHIVO_MARCA_PERSONAL/` y NO se usa; la marca personal entra como el 20 % de ESTA persona, desde la autoestima (`SISTEMA-DE-CONTENIDO.md`, «A quién y qué, en 360»). Lo marcado [CONFIRMAR] lo cierra Abel.

## LO QUE HA CAMBIADO (Abel 18/10/2026)
**Solo ha cambiado A QUIÉN le vendo:** TODO (reels, guiones virales, carruseles, títulos, descripciones, fichas de YouTube, mi historia) se enfoca SIEMPRE a la persona que no se siente suficiente: sus objeciones, sus dudas, lo que piensa de sí misma y de la realidad, y si se ve capaz.

## Quién soy en una línea
**Especialista en Autoestima.** Desarrollo personal para hombres y mujeres.

**Bio:**
- 🪞 Especialista en Autoestima
- 🤍 Sin años de terapia ni procesos largos
- 🔥 Escríbeme en privado *(texto final de Abel)*

**Lo que ofrezco:** el acompañamiento 1 a 1 de **Club Unidad**, que más adelante será grupal. En el contenido: «escríbeme por privado». Nada más que vender de momento (el webinar barato, cuando haya más seguidores).

## A quién le hablo

> **Documentos de apoyo (18/10/2026):** `A-QUIEN-LE-VENDO.md/.pdf` (situaciones y lo que siente y piensa por dentro esta persona) y `CREENCIAS-LIMITANTES-A-NECESARIAS.md/.pdf` (excusas → la creencia necesaria que las rompe). Se regeneran con `a_quien_le_vendo.py` y `creencias_limitantes.py`; si se añade una, se añade en el .py.
A la persona (hombre o mujer) que **no se siente suficiente**, aunque por fuera parezca que está bien. No hace falta que sepa que «tiene la autoestima baja»: se reconoce en lo que siente y en lo que se dice.

**Su situación (Abel 18/10/2026, «la situación me encaja», sin edad ni trabajo concreto):** por fuera parece que está bien (trabajo, amigos, a veces pareja), por dentro siente que no vale. Hace algo que no le llena, dice que sí a todo, por la noche se compara en redes con gente que vive de lo que le gusta, y tiene una idea propia (contar su historia, emprender, mostrarse) que no se atreve a empezar por miedo al qué dirán. Es la misma persona en los dos momentos del camino: hoy no se siente suficiente; al final se atreve a mostrarse y a vivir de su historia. De aquí salen las escenas concretas de cada pieza.

**Lo que siente:** que no es suficiente; vergüenza de sí misma; miedo a que la dejen o a no ser elegida; cansancio de sentirse así; comparación; un vacío que tapa con una pareja, el móvil, la comida, la fiesta o el trabajo.

**Lo que se dice (su voz interior):**
- «¿Qué me pasa? ¿Por qué no puedo ser como los demás?»
- «Si me conocieran de verdad, no me querrían.»
- «Si digo que no, se van a enfadar.»
- «Es lo que hay, no voy a encontrar nada mejor.»
- «Yo soy así, siempre me pasa lo mismo.»

**Lo que vive:** dependencia emocional; aguantar lo que no merece; complacer, no saber decir que no ni poner límites; el qué dirán; compararse; sentirse un impostor; sabotearse; necesitar que le validen.

**Lo que duda antes de pedir ayuda:** «lo mío no tiene arreglo», «esto va a ser para años», «ya lo he intentado todo», «me van a decir que me quiera más y no sé cómo», «me da vergüenza contarlo».

**Lo que piensa de la realidad:** «la vida es así, unos tienen suerte y otros no», «el amor duele», «para que te quieran tienes que dar», «el pasado me ha marcado y ya no hay nada que hacer», «los demás son más fuertes que yo».

**Si se ve capaz de conseguir la vida que quiere:** no. Cree que lo suyo es así de fábrica, que llega tarde, que necesita a alguien (una pareja, un terapeuta, un gurú) que le arregle, o que primero tiene que «estar bien» para empezar a vivir.

**Lo que le preocupa:** quedarse sola o solo; repetir lo de siempre; que se le pase la vida; decepcionar a los suyos; que se note lo que siente.

**Lo que quiere y su ambición:** estar tranquilo consigo mismo sin necesitar que nadie le valide, poner límites sin culpa, dejar de aguantar lo que no merece, gustarse… y elegirse; y, en el fondo, atreverse a hacer algo propio y vivir siendo quien es.

## Mi forma de verlo (el puente)
Explico la autoestima desde la **energía y la vibración**, y desde la **psicología** cuando la persona lo necesita. Lo explico fácil. Cómo lo cuento exactamente: `COMO-LO-EXPLICO.md`.
- **Más energía = más autoestima.** Tienes la autoestima baja porque tienes la energía baja, y la tienes baja porque te dominan **emociones bajas** (culpa, vergüenza, miedo a no valer): lo que sientes y piensas de ti y de la vida. Eso hace que te comportes y pienses de cierta manera: complacer, depender, engancharte, buscar tu valor fuera (el fútbol, la fiesta, el dinero) son la **consecuencia**, no la causa (Abel 18/10/2026). Se trabaja el diálogo interno y las emociones, y la energía sube.
- **Viene del niño interior:** de lo que viviste de pequeño. Cuando un niño no entiende lo que pasa fuera y no le encuentra explicación, se lo queda dentro y piensa que la culpa es suya, que hay algo malo en él (Abel 18/10/2026).
- **Lo que la gente llama «inconsciente» es tu campo de energía.**
- **La emoción va antes que el pensamiento** y lo genera.
- **No hay tiempo:** todo es presente, es ahora.
- **Cambiar de identidad no es ganar conciencia** («deja de ser tú», Joe Dispenza): lo que cambia tu vida es elevar tu conciencia.

**Eslogan (Abel 18/10/2026): «Espiritualidad que funciona».** Mismo molde que su eslogan anterior: responde a «¿qué vendes?» (espiritualidad que da resultados, no humo) y combina con «Especialista en Autoestima». Va en la bio y en sus vídeos cuando él quiera.

## Mis creencias (no cambian; aplicadas a la autoestima)
- **C4 · Ser complaciente no te hace buena persona** → decir que sí a todo es regalar tu energía y tu autoestima.
- **C5 · El desarrollo personal como personaje** → «quererte» no es fabricarte un personaje seguro.
- **C2 · Te has creído que vales lo que tienes o lo que haces** → raíz de la autoestima condicionada.
- **C7 · Lo que consumes te condiciona** → compararte en redes y lo que ves cada día te baja la autoestima.
- **C3 · El ego espiritual** → creerte por encima no es autoestima, es otra herida.
- **C8 · Quejarse sin querer cambiar** → a quién no le toca salvar a nadie.
- **C1 · La muerte no es real / Dios** → es un cambio de conciencia, de fase (para cuando toque).
- **Las 8 siguen igual (Abel 18/10)**, más las de «Mi forma de verlo».

## Contra lo que dice el mercado (lo que me diferencia)
| Lo que dicen | Lo que digo yo |
|---|---|
| Quiérete más / repite afirmaciones | La autoestima no se piensa: se recupera dejando de perder energía |
| Piensa en positivo | Lo que tapas te controla: primero siéntelo |
| Años de terapia hablando del pasado | Entender de dónde viene y dejar de repetirlo, sin procesos eternos |
| Autoestima es verte guapo y seguro | Autoestima es no traicionarte cuando nadie te ve |
| Busca a alguien que te quiera | Mientras busques fuera que te elijan, te vas a perder |
| Manifiesta la vida que quieres | El universo no publica por ti: energía + acción |
| Deja de ser tú y cámbiate la identidad | Cambiar de identidad no es ganar conciencia |
| Trabaja tu inconsciente con la cabeza | Tu inconsciente es tu campo de energía: se trabaja con energía |

## Mi historia, enfocada a la autoestima (TODA mi historia, contada para esta persona)
Mismos hechos y mismas fotos por época (`fotos-vida-abel`); cambia lo que se subraya:
- **La época del dinero (17.000 €/mes):** valía lo que ganaba → autoestima prestada.
- **La fiesta, las apuestas, las adicciones:** tapar el vacío.
- **Las relaciones:** buscar fuera que me eligieran.
- **Lo perdí todo a los 26** (dinero, pareja, a mí mismo; a punto de quitarme la vida): cuando se cae lo de fuera, ves que no había nada dentro.
- **Australia, solo y de cero:** reconstruir la autoestima desde dentro, sin nada que la sostuviera desde fuera.

## Cómo lo cuento
`01_MI_MARCA/mi-voz/mi-voz.md` + `correcciones.md`: de tú a tú; frases largas que fluyen; palabras de la calle; lo que la persona se dice entre comillas; exageración concreta; mi experiencia como prueba; cierre «Así que…». Estructura de cada reel: **gancho (su dolor o su voz interior) → colleja (lo que hace mal y lo que le cuesta) → solución (desde mi lente)**. Sin CTA en los reels de prueba.

## Canales
Mismos canales y formatos (trials: 10 por grabación, skill `reels-virales`); el tema es la autoestima. Energía sexual, para hombres.

---

# ARCHIVO: A-QUIEN-LE-VENDO.md

# A quién le vendo · Abel García

**Especialista en Autoestima · Espiritualidad que funciona**

**Qué vendo:** Acompañamiento 1 a 1 de Club Unidad (997 €) para la persona, hombre o mujer, que no se siente suficiente: trabajar lo que siente de sí misma y todo lo que le sube o le baja la energía (Método Unidad), sin años de terapia.

**285 descripciones**, no por edad ni sexo: escritas como lo diría la persona, en primera persona y con sus palabras (lo que vive y lo que siente y piensa por dentro de sí misma, de la vida, de lo que merece, de lo que puede conseguir, de Dios, del amor y de enseñar lo suyo; y, del 23 al 30, la vida que QUIERE). Sacadas de cómo habla la gente de verdad en foros y comentarios (VOZ-DEL-CLIENTE.md).

**Cómo usarlo (360, como Luigi y Rebeca):** siempre esta misma persona, cada pieza desde un bloque distinto, rotando; cada frase es un gancho que la persona reconoce como suyo. La colleja, lo que hace mal y lo que le cuesta; la solución, desde la lente de Abel (emociones bajas → energía baja → autoestima baja) con su ejemplo. Sin CTA.

## 1 · Por fuera, todo bien

1. «Todo el mundo me ve bien. Si supieran cómo llego a casa.»
2. «Me río con todos y luego en el coche, a solas, se me cae la cara.»
3. «Me preguntan qué tal y digo “bien, bien”, por no dar la chapa.»
4. «Siempre estoy sonriendo como tonta y por dentro tengo un dolor que no sé explicar.»
5. «Tengo trabajo, pareja y amigos. ¿De qué me quejo? Y aun así estoy fatal.»
6. «Todos me cuentan sus problemas a mí. A mí no me pregunta nadie.»
7. «Lloro en la ducha para que no me oigan.»
8. «Subo una foto riéndome, la miro y pienso: menuda mentira.»
9. «En el trabajo parezco el más seguro, y estoy pendiente de lo que piensa cada uno.» [AMBOS]
10. «Llevo tanto tiempo haciendo como que estoy bien que ya no sé cómo es estar bien.»
11. «Me lleno el día de cosas para no tener ni un minuto para pensar.»
12. «Lo mío no es tan grave, hay gente mucho peor. Así que me lo callo.»

## 2 · Dicen que sí a todo

13. «Digo que sí y nada más colgar ya me estoy arrepintiendo.»
14. «Pido perdón hasta cuando no he hecho nada.»
15. «No sé decir que no. Y luego me como el marrón yo solo.»
16. «Me quedo en planes que no me apetecen nada para no quedar mal.»
17. «Si alguien está serio, ya pienso que es por algo que he hecho yo.»
18. «“Me da igual, lo que tú quieras”. Y luego me siento invisible.»
19. «Lo hago todo en casa y encima me siento culpable si un día me siento en el sofá.»
20. «Le doy demasiada importancia a lo que piensan de mí.»
21. «Me callo lo que pienso para no liarla.»
22. «Me piden un favor, no me apetece y lo hago igual. Siempre.»
23. «Cuando por fin digo lo que pienso, me siento la peor persona del mundo.»
24. «Me hacen daño y encima soy yo el que pide perdón.»

## 3 · Necesitan a alguien para estar bien

25. «Me paso el día mirando si está en línea.»
26. «No me ha contestado en dos horas y ya me estoy montando películas.»
27. «Sé que esta relación no me hace bien, pero si lo dejo, ¿quién me va a querer?»
28. «Lo dejamos hace meses y sigo mirando sus historias.»
29. «Un fin de semana sola en casa y me entra una ansiedad que no puedo.»
30. «A poco que me den, yo lo doy todo.»
31. «Me cambio hasta la forma de vestir para gustarle.»
32. «Si no me dicen que lo he hecho bien, no me lo creo.»
33. «Vuelvo con quien me hizo daño porque estar sola me da más miedo.»
34. «Tengo cuarenta años y sigo esperando que mi padre me diga que está orgulloso de mí.»
35. «Si me deja, me quedo sin nada. Yo era yo con él.»
36. «No sé si la quiero o si me da pánico estar solo.»

## 4 · Se comparan con todos

37. «Abro Instagram cinco minutos y salgo sintiéndome una mierda.»
38. «Todos mis amigos tienen pareja, casa y niños. Y yo aquí.»
39. «Tengo treinta años y siento que he fracasado en la vida.»
40. «Sigo viviendo con mis padres y me da vergüenza decirlo.»
41. «Me veo en una foto y solo veo defectos.»
42. «Me miro al espejo y me doy asco.»
43. «Me alegro por los demás, pero por dentro me escuece.»
44. «Siempre hay alguien más guapo, más listo o con más dinero que yo.»
45. «No enseño lo que hago porque lo de los demás es mejor.» [AMBOS]
46. «En mi familia siempre fui el que no daba la talla.»
47. «En un grupo me hago pequeñito y casi ni hablo.»
48. «Me veo más vieja que mi amiga de sesenta.»

## 5 · Buscan su valor fuera

49. «Si me va bien en el trabajo, estoy bien. Si no, soy una mierda.» [AMBOS]
50. «Voy al gimnasio todos los días y sigo sin gustarme.»
51. «“Cuando cobre más, ahí sí”. Eso llevo diciendo diez años.» [AMBOS]
52. «Me dicen veinte cosas buenas y una mala, y me quedo con la mala toda la semana.»
53. «Me compro algo, estoy contento dos días y vuelta a lo mismo.»
54. «Si no voy arreglada, no salgo de casa.»
55. «Si descanso, me siento un vago.»
56. «Lo he conseguido todo para que mi familia me vea, y sigue sin verme.» [AMBOS]
57. «Si fallo en algo, siento que el que ha fallado soy yo.»
58. «Me he quedado sin trabajo y ahora no sé ni quién soy.» [AMBOS]
59. «Siempre tengo que ser el más fuerte, el que más trabaja, el que nunca falla.»

## 6 · Tapan el vacío

60. «Lo primero que hago al despertar es coger el móvil. Lo último antes de dormir, también.»
61. «Cuanto más me miro, más ansiedad me entra y más como.»
62. «Sin una cerveza por la noche no consigo desconectar.»
63. «Salgo todos los findes, y el lunes estoy peor que el viernes.»
64. «Me pongo series hasta las tres para no pensar.»
65. «Me digo que es la última vez. Siempre es la última vez.»
66. «Tengo el armario lleno de ropa que no me pongo.»
67. «No aguanto el silencio. Siempre tengo algo puesto de fondo.»
68. «Echo doce horas en el trabajo para no tener que estar en casa.» [AMBOS]
69. «Me río de todo, hasta de lo que me duele. Así no tengo que hablarlo.»
70. «Cuando todo se calla, noto un agujero en el pecho.»

## 7 · Lo que se dicen por dentro

71. «Soy tonto. ¿Cómo he podido decir eso?»
72. «Me voy a la cama repasando todo lo que dije mal en el día.»
73. «Si me conocieran de verdad, no me querría nadie.»
74. «Me dicen que estoy guapa y pienso que lo dicen por quedar bien.»
75. «Siento que molesto hasta cuando hablo.»
76. «No me veo capaz de hacer nada bien. Y si me sale bien, pienso que ha sido suerte.»
77. «¿Qué me pasa? ¿Por qué no puedo ser normal?»
78. «Algo empieza a ir bien y ya estoy esperando a fastidiarlo.»
79. «Me castigo tres días por un fallo de nada.»
80. «Me miro y en la cabeza me suena: “gorda”, “fea”, “inútil”.»
81. «Para qué voy a soñar con nada, si no lo voy a conseguir.»
82. «Soy una carga para los que me quieren.»

## 8 · Ya lo han probado todo

83. «Me he leído veinte libros de autoestima y estoy igual.»
84. «Fui años al psicólogo. Entiendo perfectamente lo que me pasa. Y no cambia nada.»
85. «Me pongo delante del espejo a decirme cosas bonitas y no me creo ni una.»
86. «He empezado a meditar diez veces. Diez veces lo he dejado.»
87. «Vuelvo de un retiro como nuevo y a la semana estoy igual.»
88. «Estoy harto de que me digan “quiérete más”. ¿Cómo, exactamente?»
89. «Lo sé todo del niño interior y no sé qué hacer con el mío.»
90. «Me he gastado un dineral en cosas que no me han servido.» [AMBOS]
91. «Ya desconfío de todo lo que suena a desarrollo personal.» [AMBOS]
92. «Lo entiendo con la cabeza, pero por dentro sigo igual.»
93. «Mejoro dos semanas y vuelvo a caer.»
94. «Igual lo mío no tiene arreglo.»

## 9 · Lo que vivieron de pequeños

95. «Mi padre jamás estaba satisfecho con nada.»
96. «En mi casa no se lloraba. “No llores, que no es para tanto”.»
97. «Mis padres se separaron y yo pensaba que era por mi culpa.»
98. «Aprendí que, si me portaba bien, había menos gritos.»
99. «Con ocho años ya hacía de mayor en casa.»
100. «En el colegio se reían de mí, y todavía me siento así en cualquier grupo.»
101. «Me comparaban con mi hermano, y sigo sintiendo que no llego.»
102. «Nos mudamos y nunca volví a sentirme de ningún sitio.»
103. «Alguien me levanta la voz y me quedo bloqueado, como cuando era pequeño.»
104. «Estoy repitiendo con mis hijos lo que me hicieron a mí, y me odio por ello.»
105. «No me acuerdo de la última vez que me sentí protegida.»

## 10 · Tienen la energía por los suelos

106. «Duermo ocho horas y me levanto como si me hubiera pasado un camión por encima.»
107. «Ando todo el día triste, sin ganas de nada.»
108. «Tengo un nudo en el estómago casi todos los días.»
109. «De casa al trabajo y del trabajo a casa. Así llevo años.»
110. «El domingo por la tarde ya me empieza la ansiedad.»
111. «Ya no hago nada de lo que me gustaba. Ni me acuerdo de cuándo lo dejé.»
112. «Salto por cualquier tontería y luego no sé ni por qué.»
113. «No me acuerdo de la última vez que me reí de verdad.»
114. «Se me ha ido la chispa que yo tenía.»
115. «Veo pasar los años y todo sigue igual.»
116. «Sé que algo tiene que cambiar y no sé ni por dónde empezar.»

## 11 · Lo que sienten de sí mismos

117. «Siento que tengo algo roto que los demás no tienen.»
118. «Sobro en casi todos los sitios a los que voy.»
119. «Me quiero más bien poco.»
120. «Soy demasiado: demasiado sensible, demasiado intensa, demasiado todo.»
121. «Me da vergüenza ser yo, y no sé ni de qué.»
122. «No me reconozco. No sé en qué me he convertido.»
123. «Si no estoy haciendo algo por alguien, no sé quién soy.»
124. «Me paso el día haciendo de alguien que no soy.»
125. «Nadie me conoce de verdad. Ni yo.»
126. «Me falta algo y no sé ni ponerle nombre.»

## 12 · Lo que sienten de la vida

127. «Mi vida va cuesta abajo y sin frenos.»
128. «La semana es aguantar hasta el viernes.»
129. «A otros les sale todo. A mí todo me cuesta el doble.»
130. «Cuando algo va bien, ya sé que viene el palo.»
131. «Me levanto y no sé ni para qué.»
132. «Ser feliz es para otros.»
133. «Estoy esperando a que pase algo que me cambie la vida.»
134. «Miro atrás y siento que he tirado los mejores años.»
135. «La vida es esto: sufrir y tirar.»
136. «La vida me pasa por delante y yo solo miro.»

## 13 · Lo que creen que merecen

137. «Si me pasa algo bueno, me siento culpable.»
138. «Aguanto lo que sea porque no creo que pueda aspirar a más.»
139. «Si alguien me trata bien, desconfío.»
140. «No pido un aumento porque ¿quién soy yo para pedirlo?» [AMBOS]
141. «Descansaré cuando termine todo. Y nunca termino.»
142. «Me conformo con migajas porque es lo que he tenido siempre.»
143. «Algo habré hecho para merecer esto.»
144. «Estar bien cuando mi madre está mal me parece de mala persona.»
145. «Pedir más me parece de desagradecido.»
146. «Lo bueno siempre les pasa a otros.»

## 14 · Lo que creen que pueden conseguir

147. «¿Quién soy yo para hacer eso?» [AMBOS]
148. «No lo intento, y así no fallo.» [AMBOS]
149. «Ya sabía yo que no iba a salir.»
150. «Ya no estoy a tiempo de nada.»
151. «Me pongo metas pequeñas para no llevarme el chasco.» [AMBOS]
152. «De aquí no salgo. Esto es lo que me ha tocado.»
153. «No soy tan listo como para cambiar de vida.» [AMBOS]
154. «Otros pueden. Yo no.»
155. «Necesito que venga alguien y me saque de aquí.»
156. «Vivir una vida que me guste es pedir demasiado.»

## 15 · Lo que piensan de Dios, del universo y de lo espiritual

157. «¿Por qué a mí? ¿Qué he hecho yo?»
158. «Siento que Dios se ha olvidado de mí.»
159. «Rezo, pido señales y no me llega nada.»
160. «Desde que murió mi madre no creo en nada.»
161. «Leo cosas espirituales y me siento peor, porque yo no estoy en paz.»
162. «Estaré pagando algo, porque esto no es normal.»
163. «Lo de manifestar a mí no me funciona. Algo hago mal.»
164. «Tengo miedo a morirme y no lo hablo con nadie.»
165. «Me pregunto si mi padre estará bien, esté donde esté.»
166. «No me siento unida a nada: ni a la gente, ni a mí, ni a nada.»
167. «La vida me pone pruebas y ya no puedo con una más.»

## 16 · Lo que sienten del amor y de la gente

168. «Siempre doy más de lo que recibo.»
169. «No me fío de nadie. Ya me la han liado demasiadas veces.»
170. «Nadie me elige primero.»
171. «Al final todos se cansan de mí.»
172. «Estoy rodeada de gente y me siento sola.»
173. «Si le digo lo que siento, le pierdo.»
174. «El amor de verdad no es para mí.»
175. «En las conversaciones ni participo. No sé qué decir.»
176. «Me necesitan, pero no sé si me quieren.»
177. «Me voy a quedar sola. Lo veo venir.»
178. «Voy por la calle y siento que todos me miran y piensan lo peor.»

## 17 · Lo suyo, sin atreverse a enseñarlo

179. «Tengo veinte vídeos grabados en el móvil y ninguno subido.» [AMBOS]
180. «Me pongo a grabar, me escucho la voz y lo borro.» [AMBOS]
181. «Escribo el guion, lo reescribo diez veces y al final no grabo nada.» [AMBOS]
182. «No sé ni de qué hablar. ¿A quién le va a interesar lo mío?» [AMBOS]
183. «Subo algo y me paso la tarde mirando cuántos likes tiene.» [AMBOS]
184. «Si me ve alguien del trabajo, me muero de la vergüenza.» [AMBOS]
185. «¿Qué va a pensar mi familia si me ve hablando a una cámara?» [AMBOS]
186. «Empiezo con muchas ganas, a la semana lo dejo, y me siento un fracasado otra vez.» [AMBOS]
187. «Veo a gente que empezó después que yo y ya vive de esto.» [AMBOS]
188. «Me da vergüenza cobrar por lo que sé. Me siento un vendehumos.» [AMBOS]
189. «Con doscientos seguidores, ¿quién soy yo para dar consejos?» [AMBOS]
190. «Publico lo que creo que va a gustar, no lo que pienso de verdad.» [AMBOS]
191. «Me da pánico que me pongan un comentario malo.» [AMBOS]
192. «Mi historia me la guardo. Eso no se le cuenta a nadie.» [AMBOS]
193. «Pienso en dejar el trabajo y vivir de lo mío, y me entra el pánico.» [AMBOS]

## 18 · Quieren tener confianza

194. «En la reunión tengo la idea y me la callo. Luego la dice otro y le aplauden.»
195. «Me cuesta mirar a la gente a los ojos cuando hablo.»
196. «Antes de llamar por teléfono repaso tres veces lo que voy a decir.»
197. «Me gusta alguien y no le digo nada, por si acaso.»
198. «Entro en un sitio lleno de gente y no sé ni dónde poner las manos.»
199. «Me tiembla la voz en cuanto todos me miran.»
200. «Me pruebo cinco veces la ropa antes de salir y al final me quedo en casa.»
201. «Me pongo a la defensiva en cuanto alguien me lleva la contraria.»
202. «Ojalá ser de esa gente que entra en un sitio y se le nota segura.»

## 19 · Quieren tener más energía

203. «Llego a las cuatro de la tarde arrastrándome, a base de cafés.»
204. «Tengo mil cosas que hacer y me paso la tarde tirado en el sofá con el móvil.»
205. «Me apunto al gimnasio en enero y en febrero ya no voy.»
206. «Hay gente con la que quedo y vuelvo a casa reventado.»
207. «Me levanto y lo primero que hago es mirar las noticias y el Instagram.»
208. «Me acuesto a las tantas viendo vídeos, sabiendo que mañana lo voy a pagar.»
209. «Ya no me apetece ni quedar. Todo me da pereza.»
210. «Digo que mañana empiezo, y mañana estoy igual de cansado.»
211. «Antes tenía ganas de comerme el mundo. Ahora con llegar al viernes me vale.»

## 20 · Quieren dejar de pensar en negativo

212. «Me meto en la cama y la cabeza no para.»
213. «Me imagino lo peor antes de que pase nada.»
214. «Me dicen algo y le doy vueltas tres días.»
215. «Intento pensar en positivo y a los cinco minutos estoy otra vez igual.»
216. «Me escribe mi jefe “¿tienes un momento?” y ya pienso que me echan.»
217. «Siempre veo lo que falta, nunca lo que tengo.»
218. «Quedo con mis amigos y acabamos siempre quejándonos de todo.»
219. «Si algo va bien, pienso que pronto se va a torcer.»

## 21 · Quieren dejar de sentirse mal

220. «Me levanto bien y de repente, sin motivo, me viene el bajón.»
221. «Estoy en una fiesta y me siento fuera, como si no pintara nada.»
222. «Me siento culpable por todo, hasta por descansar.»
223. «Me da vergüenza todavía lo que hice hace diez años.»
224. «Como sin hambre cuando estoy mal, y luego me siento peor.»
225. «Me enfado por todo y luego me arrepiento.»
226. «Tengo envidia de gente que quiero, y me siento fatal por tenerla.»
227. «Quiero sentirme bien un día entero, sin motivo, solo bien.»

## 22 · Quieren elevar su energía

228. «Quiero subir mi vibración y no sé ni qué significa eso.»
229. «Pruebo lo de la ley de la atracción y no me pasa nada.»
230. «Hago la lista de gratitud por la mañana y por la tarde estoy fatal.»
231. «Me compro cuarzos, inciensos, de todo, y sigo igual.»
232. «Siento que hay algo más, pero no sé por dónde empezar.»
233. «Medito y lo único que consigo es pensar más.»
234. «Me dicen que atraigo lo que me pasa y encima me siento culpable.»
235. «Veo vídeos de espiritualidad hasta las tantas y al día siguiente nada cambia.»

## 23 · Quiere cuidarse (hábitos)

236. «Quiero levantarme con ganas, no arrastrándome.»
237. «Quiero ir al gimnasio porque me apetece, no para castigarme.»
238. «Quiero comer bien sin estar contando cada cosa que me meto en la boca.»
239. «Quiero dormir del tirón, sin la cabeza dándome vueltas.»
240. «Quiero tener mis ratos para mí sin sentirme culpable.»
241. «Quiero cumplir lo que me digo, aunque sea salir a andar media hora.»
242. «Quiero mirarme al espejo y caerme bien.»

## 24 · Quiere llenarse de otras cosas (lo que lee, mira y escucha)

243. «Quiero dejar de tragarme Instagram hasta las tantas.»
244. «Quiero leer cosas que me sirvan de verdad, no frases bonitas.»
245. «Quiero escuchar a gente que ya está donde yo quiero estar.»
246. «Quiero aprender cosas de energía, de la mente, de por qué soy como soy.»
247. «Quiero dejar de ver noticias que me dejan con mal cuerpo todo el día.»
248. «Quiero que lo que veo me suba, no que me compare.»

## 25 · Quiere otras conversaciones y otros amigos

249. «Quiero quedar con gente que hable de sueños, no de quejas.»
250. «Quiero un amigo al que poder contarle lo que me pasa sin que me juzgue.»
251. «Quiero dejar de reírle las gracias a quien me hace de menos.»
252. «Quiero sentirme a gusto en un grupo, sin estar pendiente de caer bien.»
253. «Quiero poder decir lo que pienso en una cena sin pasarlo mal.»
254. «Quiero rodearme de gente que me empuje hacia arriba.»

## 26 · Quiere una buena pareja

255. «Quiero una pareja que me elija, no que me aguante.»
256. «Quiero estar con alguien sin miedo a que me deje.»
257. «Quiero que me quieran como soy, sin tener que hacer el papel.»
258. «Quiero poder decir que no a mi pareja sin que sea un drama.»
259. «Quiero estar bien solo para elegir bien con quién estoy.»
260. «Quiero una relación tranquila, sin estar mirando el móvil cada cinco minutos.»

## 27 · Quiere estar bien con su familia

261. «Quiero ir a casa de mis padres y no salir con mal cuerpo.»
262. «Quiero que mi familia esté orgullosa de mí, y estarlo yo primero.»
263. «Quiero poder ayudar a los míos cuando lo necesiten.»
264. «Quiero que mis hijos tengan un padre que se quiere.»
265. «Quiero sentirme querido y apoyado en mi casa.»
266. «Quiero dejar de repetir lo que vi en casa de pequeño.»

## 28 · Quiere crear la vida de sus sueños

267. «Quiero trabajar de lo mío y no tener que pedir permiso para irme de vacaciones.»
268. «Quiero crear mi propio negocio y vivir de lo que sé.»
269. «Quiero poder comprarme lo que quiera sin mirar el precio.»
270. «Quiero viajar cuando me apetezca.»
271. «Quiero tener más libertad: de tiempo, de dinero y de dónde vivir.»
272. «Quiero llegar a viejo sin la sensación de que me quedé con las ganas.»
273. «Quiero hacer algo grande, siento que he venido a algo más.»

## 29 · Quiere sentirse bien por dentro

274. «Quiero estar tranquilo conmigo, sin necesitar que nadie me diga que valgo.»
275. «Quiero dejar de pensar lo peor de todo.»
276. «Quiero sentirme suficiente sin tener que demostrar nada.»
277. «Quiero confiar en mí cuando tengo que tomar una decisión.»
278. «Quiero ser feliz sin motivo, un martes cualquiera.»
279. «Quiero perdonarme lo que hice y dejar de cargarlo.»

## 30 · Quiere vivir con energía y sentido

280. «Quiero sentir que mi vida tiene sentido.»
281. «Quiero notar que lo que hago me llena.»
282. «Quiero saber escuchar mi intuición y fiarme de ella.»
283. «Quiero sentirme unido a algo más grande, sin que nadie me venda humo.»
284. «Quiero dejar de vivir en piloto automático.»
285. «Quiero estar presente, aquí, y no siempre en mi cabeza.»

---

# ARCHIVO: CREENCIAS-LIMITANTES-A-NECESARIAS.md

# Creencias limitantes → creencias necesarias · Abel García

104 creencias en 13 familias. A la izquierda, el diálogo interno que frena a la persona; a la derecha, lo que necesita llegar a creer, dicho como se lo diría Abel a un amigo: directo y sin rodeos.

Lente de Abel: emociones bajas → energía baja → autoestima baja. Lo de fuera (complacer, engancharse, buscar el valor fuera) es la consecuencia.

[AMBOS] = también sirve para la parte de marca personal y negocio, siempre mezclada con la autoestima (80 % desarrollo personal, 20 % marca personal). Cómo usarlo: en reels, la limitante es el gancho con connotación negativa y la necesaria la solución; en stories (AYUDAR), una al día; en carruseles y guiones, la objeción que se rompe. Lo clínico se deriva a un profesional.

## 1 · Lo que piensan de sí mismos

| # | Creencia limitante | Creencia necesaria |
|---|---|---|
| 1 | Es que soy un inútil, no hago nada bien. | No eres un inútil, solo te fijas en lo que te sale mal y lo bueno ni lo ves. |
| 2 | Valgo lo que tengo. [AMBOS] | Si mañana te quedas sin nada, sigues siendo tú; lo que tienes no es lo que vales. |
| 3 | Si no hago las cosas bien, no valgo. [AMBOS] | La vas a cagar mil veces y vas a seguir valiendo lo mismo; lo que te hunde no es el fallo, es cómo te machacas después. |
| 4 | Tengo 35 años y he fracasado en la vida. | Te han salido cosas mal, como a todos; fracasar de verdad es quedarte llorándolo toda la vida. |
| 5 | Algo malo tengo, porque a los demás no les pasa. | No tienes nada malo, tienes cosas que te dolieron y que nunca has querido mirar. |
| 6 | Yo soy así y no voy a cambiar. | No eres así, llevas años haciéndolo igual, que no es lo mismo. |
| 7 | Me miro al espejo y me doy asco. | Tu cuerpo te ha aguantado todo lo que le has hecho; empieza por dejar de tratarlo como a un enemigo. |
| 8 | Si me conocieran de verdad, saldrían corriendo. | Quien salga corriendo al conocerte entero te está haciendo un favor; el que se quede, ese vale. |
| 9 | Me quiero más bien poco. | No hace falta que te quieras mucho mañana, empieza hoy por dejar de machacarte. |
| 10 | Soy un rollo, la gente se aburre conmigo. | No eres un rollo, estás con gente con la que no conectas. |

## 2 · Lo que creen que merecen

| # | Creencia limitante | Creencia necesaria |
|---|---|---|
| 11 | No me merezco nada bueno. | Te mereces lo mismo que cualquiera; lo que pasa es que te has acostumbrado a las migajas. |
| 12 | Me lo tengo merecido. | Nadie se merece sentirse así, y tú tampoco, por mucho que te lo hayas creído. |
| 13 | Si alguien me trata bien, algo querrá. | Hay gente que te trata bien porque sí; si desconfías de todo el que te quiere, te vas a quedar solo. |
| 14 | Con lo que tengo, ya debería estar contento. | Puedes estar agradecido y querer más a la vez; una cosa no quita la otra. |
| 15 | Para qué voy a pedir más, si no me lo van a dar. [AMBOS] | Si no lo pides, seguro que no te lo dan. |
| 16 | Si me va bien, ya vendrá el palo. | Si te va bien, disfrútalo; esperar el palo es la forma más rápida de que llegue. |
| 17 | No me he ganado descansar. | Descansar no es un premio, es lo que te deja seguir; si no paras tú, te para el cuerpo. |

## 3 · Lo que creen que pueden conseguir

| # | Creencia limitante | Creencia necesaria |
|---|---|---|
| 18 | Yo no sirvo para eso. [AMBOS] | No lo has hecho nunca, que no es lo mismo que no servir. |
| 19 | Eso es para otros, no para alguien como yo. [AMBOS] | Los que lo consiguieron no eran mejores que tú, simplemente empezaron. |
| 20 | Ya es tarde para mí. [AMBOS] | Mientras sigas aquí, no es tarde; tarde es lo que te dices para no empezar. |
| 21 | No soy lo bastante listo. [AMBOS] | No te falta cabeza, te falta creértelo. |
| 22 | Siempre empiezo las cosas y nunca las acabo. [AMBOS] | Lo dejas cuando te vienes abajo; cuida cómo te sientes y verás cómo acabas lo que empiezas. |
| 23 | Para qué lo voy a intentar, si va a salir mal. [AMBOS] | Si no lo intentas, ya ha salido mal. |
| 24 | Lo mío no tiene arreglo. | Lo tuyo tiene arreglo, lo que pasa es que nadie te ha enseñado a arreglarlo desde dentro. |
| 25 | Yo solo no puedo, y pedir ayuda me da vergüenza. | Solo no has podido en años; pedir ayuda no es de débiles, es de quien ya se ha cansado de dar vueltas. |

## 4 · Lo que creen de la vida

| # | Creencia limitante | Creencia necesaria |
|---|---|---|
| 26 | Yo es que tengo mala suerte. | No tienes mala suerte, tienes la energía por los suelos, y desde ahí todo te parece un castigo. |
| 27 | ¿Por qué siempre me pasa todo a mí? | Si siempre te pasa lo mismo, no es la vida, es algo que llevas dentro y que se repite. |
| 28 | Mi vida va cuesta abajo y sin frenos. | Estás en un mal momento, no en una mala vida; no confundas una etapa con lo que eres. |
| 29 | Unos nacen con estrella y otros estrellados. | No naciste estrellado, aprendiste a vivir así, y lo que se aprende se cambia. |
| 30 | La vida es aguantar. | Llevas años aguantando; ya va siendo hora de vivir un poco. |
| 31 | Ser feliz no es para mí. | Ya has sido feliz alguna vez, así que sabes que puedes. |
| 32 | Lo mejor de mi vida ya pasó. | Lo mejor no ha pasado, es que desde donde estás ahora no lo ves. |
| 33 | Esto es lo que hay. | Esto es lo que hay hoy; mañana depende de lo que hagas con lo que sientes. |

## 5 · Lo que creen de los demás y del entorno

| # | Creencia limitante | Creencia necesaria |
|---|---|---|
| 34 | La gente al final siempre te falla. | Te han fallado unos cuantos, no todo el mundo; no pagues con los nuevos lo que te hicieron los de antes. |
| 35 | Todos tienen la vida resuelta menos yo. | Estás comparando tu por dentro con el escaparate de los demás, y así siempre pierdes. |
| 36 | Me miran y piensan que soy un desastre. [AMBOS] | La mayoría ni se fija en ti, bastante tienen con lo suyo. |
| 37 | Si digo que no, se van a enfadar. | Si alguien se enfada porque dices que no, ya sabes cuánto le importas. |
| 38 | Tengo que caerle bien a todo el mundo. [AMBOS] | No le vas a caer bien a todo el mundo, y menos mal, porque te volverías loco intentándolo. |
| 39 | Si me alejo de esta gente, me quedo solo. | Mejor solo un tiempo que mal acompañado toda la vida. |
| 40 | En mi familia nunca me van a entender. | Puede que no te entiendan nunca, y aun así tú te puedes entender. |
| 41 | Si cuento cómo estoy, voy a ser una decepción. | Quien te quiere prefiere saber cómo estás de verdad que verte fingir. |

## 6 · Lo que creen del amor

| # | Creencia limitante | Creencia necesaria |
|---|---|---|
| 42 | Nadie me va a querer así. | Te van a querer así, pero primero deja de esconder cómo eres. |
| 43 | A poco que me den, yo lo doy todo. | Darlo todo a cambio de migajas no es amor, es miedo a que te dejen. |
| 44 | Todos tienen pareja menos yo. | Estar solo ahora no significa estar solo siempre; mejor eso que estar con cualquiera. |
| 45 | Si me ha dejado, es porque no valgo. | Se ha acabado, nada más; eso no dice nada de lo que vales. |
| 46 | Siempre me fijo en quien no me hace caso. | Te fijas en quien te ignora porque es lo que conoces desde pequeño; eso se cambia. |
| 47 | Al final todos se cansan de mí. | Quien se cansa de ti no era para ti. |
| 48 | Más vale esto que estar solo. | Estar solo da miedo, pero estar mal acompañado te consume. |
| 49 | Si me enfado, me deja. | Si alguien se va porque te enfadas, no te quería a ti, quería que no molestaras. |

## 7 · Lo que creen del dinero, el trabajo y el éxito

| # | Creencia limitante | Creencia necesaria |
|---|---|---|
| 50 | ¿Quién soy yo para enseñar esto? [AMBOS] | Eres alguien que ya ha pasado por donde otros están ahora; con eso basta. |
| 51 | Si cobro más, pensarán que soy un vendehumos. [AMBOS] | El que piensa eso no te iba a pagar igual; cobra lo que vale lo que haces. |
| 52 | Lo mío no le interesa a nadie. [AMBOS] | Lo que has vivido le puede servir a alguien que hoy está como tú estabas, pero si no lo enseñas, nunca lo sabrá. |
| 53 | Si me muestro, me van a criticar. [AMBOS] | Te van a criticar igual, así que mejor que sea siendo tú. |
| 54 | Cuando gane más, estaré bien. [AMBOS] | Yo ganaba 17.000 € al mes y me sentía vacío; el dinero no arregla lo que sientes. |
| 55 | Si no tengo éxito, no soy nadie. [AMBOS] | Eres alguien con éxito y sin él; si no, cuando se acabe el éxito, se acaba también tu valor. |
| 56 | El dinero no es para la gente como yo. [AMBOS] | Al dinero le da igual de dónde vienes; lo que te frena es lo que te dices. |
| 57 | Gastarme dinero en mí es tirarlo. [AMBOS] | Te gastas dinero en el móvil, en el coche y en salir; si en ti no, es porque no crees que lo valgas. |
| 58 | Si gano más, me respetarán más. [AMBOS] | Quien te respeta por lo que ganas no te respeta a ti. |

## 8 · Lo que creen de Dios, del destino y de lo espiritual

| # | Creencia limitante | Creencia necesaria |
|---|---|---|
| 59 | Dios se ha olvidado de mí. | No estás solo; lo que pasa es que llevas tanto tiempo sin parar que no lo notas. |
| 60 | ¿Qué he hecho yo para merecer esto? | No has hecho nada para merecerlo; te ha pasado, y puedes salir. |
| 61 | Estaré pagando algo, porque esto no es normal. | No estás pagando nada, estás en un mal momento, y se puede cambiar. |
| 62 | Si fuera más espiritual, no me pasaría esto. | La gente espiritual también lo pasa mal; la diferencia es cómo lo vive. |
| 63 | Lo espiritual es para gente rara. | Lo espiritual es cómo te hablas cuando nadie te escucha; de raro, nada. |
| 64 | Lo de la energía es una tontería. | Hay gente que te deja vacío y gente que te llena; eso es energía, lo llames como lo llames. |
| 65 | Los que se fueron ya no están. | Ya no los ves, pero lo que te dieron lo llevas encima. |

## 9 · Lo que creen de sus emociones

| # | Creencia limitante | Creencia necesaria |
|---|---|---|
| 66 | Si me pongo a pensar, me hundo. | Si no lo miras, te hundes igual, solo que más despacio. |
| 67 | Llorar es de débiles. | Débil es seguir tragándotelo hasta que revientes por cualquier tontería. |
| 68 | Tengo que poder con todo. | No puedes con todo, y no pasa nada por decirlo. |
| 69 | Lo mío no es para tanto, hay gente peor. | Que haya gente peor no quita que tú estés mal. |
| 70 | Si cuento lo que me pasa, molesto. | A quien te quiere no le molesta saber cómo estás; al que le molesta, ya sabes. |
| 71 | Mejor no pensarlo y tirar. | Tirar sin mirarlo es lo que te ha traído hasta aquí. |

## 10 · Lo que creen de su pasado

| # | Creencia limitante | Creencia necesaria |
|---|---|---|
| 72 | Lo que viví de pequeño me ha jodido la vida. | Te marcó, pero no tiene por qué decidir lo que haces a partir de hoy. |
| 73 | Fue culpa mía. | Eras un niño; no era culpa tuya. |
| 74 | Mis padres tienen la culpa de cómo soy. | Hicieron lo que supieron; lo que hagas ahora ya es cosa tuya. |
| 75 | No puedo perdonar. | Perdonar no es darles la razón, es dejar de cargarlo tú. |
| 76 | He tirado mi vida. | Has perdido años, sí, pero te quedan muchos más que perder si sigues igual. |
| 77 | En mi familia todos somos así. | Pues sé el primero de tu casa que lo hace distinto. |

## 11 · Lo que creen del cambio

| # | Creencia limitante | Creencia necesaria |
|---|---|---|
| 78 | La gente no cambia. | Tú ya has cambiado otras veces; lo que no cambia es quien no quiere mirarse. |
| 79 | Esto va para años. | Hay cosas que tardan, pero empezar a sentirte mejor depende de cuánto estés dispuesto a hacer. |
| 80 | Ya lo he probado todo. | Has probado mil cosas por fuera; lo de dentro no lo has tocado. |
| 81 | Cuando esté bien, empiezo a vivir. | Empieza a vivir y ya te irás poniendo bien por el camino. |
| 82 | Si cambio, voy a perder a gente. | Si alguien se va porque estás mejor, no te quería tanto. |
| 83 | Pedir ayuda es de débiles. | Débil es seguir igual por orgullo; pedir ayuda es de valientes. |
| 84 | Pensar en mí es ser egoísta. | Si tú estás bien, los que tienes al lado lo notan; egoísta es obligarles a cargar contigo mal. |
| 85 | Lo de la autoestima es humo. | Humo son las frases bonitas; sentirte distinto contigo no lo es. |
| 86 | Me gustaría arreglarlo solo, pero llevo así años. | Si en años solo no lo has arreglado, igual toca dejar que te acompañen. |

## 12 · Lo que creen de mostrarse y de vivir de lo suyo

| # | Creencia limitante | Creencia necesaria |
|---|---|---|
| 87 | Tengo que tenerlo todo perfecto antes de publicar. [AMBOS] | Perfecto no publica nadie; sube lo de hoy y mañana lo haces mejor. |
| 88 | Mi cara y mi voz en vídeo dan pena. [AMBOS] | Te ves raro porque no estás acostumbrado a verte; la gente no mira tu cara, escucha lo que dices. |
| 89 | Si lo ve mi familia, qué vergüenza. [AMBOS] | Tu familia ya opina de todo lo que haces; que opine también de algo que te hace feliz. |
| 90 | Ya hay mucha gente hablando de esto. [AMBOS] | Hay mucha gente, pero nadie con tu historia, y a ti te va a escuchar quien vivió lo mismo. |
| 91 | Sin seguidores no vale la pena. [AMBOS] | Todos empezaron con cero; los seguidores vienen de seguir publicando, no al revés. |
| 92 | Cobrar por ayudar está mal. [AMBOS] | Si ayudas de verdad, cobrar es lo que te deja seguir ayudando. |
| 93 | Lo dejo porque no funciona. [AMBOS] | No funciona porque lo dejas; en tres semanas nadie ve nada. |
| 94 | Primero tengo que estar bien yo para enseñar a otros. [AMBOS] | Enseñas lo que ya has pasado, no hace falta haber llegado a todo. |

## 13 · Lo que creen de la confianza, la energía y sus pensamientos

| # | Creencia limitante | Creencia necesaria |
|---|---|---|
| 95 | Seguro se nace. | Nadie nace seguro; los que lo parecen han hecho el ridículo más veces que tú. |
| 96 | La confianza se tiene o no se tiene. | La confianza sube cada vez que haces lo que te dijiste que ibas a hacer. |
| 97 | Estoy cansado porque trabajo mucho. | Cansa más lo que aguantas que lo que trabajas. |
| 98 | Cuando tenga energía, empiezo. | La energía viene de empezar, no al revés. |
| 99 | No puedo controlar lo que pienso. | No eliges lo primero que te viene a la cabeza, pero sí quedarte ahí dándole vueltas. |
| 100 | Tengo que pensar en positivo. | No hace falta pensar en positivo, hace falta dejar de tapar lo que sientes. |
| 101 | Soy negativo, siempre lo he sido. | No eres negativo, llevas años rodeado de lo que te baja. |
| 102 | Lo de la vibración es cosa de hippies. | Llámalo como quieras: hay cosas que te dejan con ganas y cosas que te dejan vacío, y eso lo notas. |
| 103 | Si me siento mal, es que algo va mal en mí. | Sentirte mal no es estar roto, es algo que te pide que lo mires. |
| 104 | Cuando todo se arregle, me sentiré bien. | Primero te sientes mejor y luego se van arreglando las cosas. |

---

# ARCHIVO: VOZ-DEL-CLIENTE.md

# Voz del cliente · cómo hablan de verdad (investigación 18/10/2026)

Fuente para que A-QUIEN-LE-VENDO y CREENCIAS suenen humanas. Son frases reales, cortas, sacadas de foros y comentarios en español. Úsalas para copiar el **registro**, no para pegarlas tal cual en el contenido.

## Cómo se nota que es real (y no IA / Mr. Wonderful)
- Hablan de **escenas concretas**: el espejo, el móvil, el coche de vuelta, la cama, la familia, el instituto.
- Usan **palabras de la calle**: «una mierda», «fatal», «por los suelos», «como tonta», «me da asco», «rayado».
- Se **contradicen**: «me gustaría solucionarlo sola, pero llevo así mucho tiempo».
- Minimizan: «hay gente peor», «intento no pensar en ello y vivir así».
- **Nunca** hablan con antítesis bonitas («no soy lo que hago; soy quien lo hace»), ni con punto y coma, ni con palabras como «abrazar», «sanar», «tu mejor versión» o «brillar».

## Frases reales
**Cómo se ven**
- «Me quiero más bien poco.» (abroparaguas)
- «Tengo la autoestima por los suelos desde los tiempos del instituto.» (abroparaguas)
- «Una autoestima de mierda; intento no pensar en ello y vivir así.» (abroparaguas)
- «No me veo capaz de hacer nada bien, y aunque luego lo haga bien, siempre pienso que no voy a saber.» (abroparaguas)
- «Me siento muy fracasada e inútil.» / «No me reconozco.» (mediavida)
- «Para no darme asco cuando me veo.» (weloversize)
- «Escucho en mi mente: gorda, fea.» (comentarios del blog de Carmen Martín)

**Cómo se comparan**
- «Tiendo a sentirme inferior a los demás.» (abroparaguas)
- «Me veo más vieja que mi amiga de 60.» (Carmen Martín)
- «Tengo 30 años y he fracasado en la vida.» / «Vivo con mis padres, ¿soy un fracasado?» (forocoches)
- «Me miran diciendo: mira la gorda.» (weloversize)

**Con los demás**
- «No sé decir un no.» / «Doy demasiada importancia a lo que los demás piensan de mí.» (abroparaguas)
- «A poco que ellos me den, yo les doy todo.» (abroparaguas)
- «En las conversaciones ni participo, no sé qué decir.» (foros24h, hombre de 32 años)
- «Me da hasta vergüenza decírselo a mi familia; siento que voy a ser una decepción.» (mediavida)
- «Mi padre jamás estaba satisfecho con nada.» (abroparaguas)

**Cómo sienten la vida**
- «Mi vida va cuesta abajo y sin frenos.» (foros24h)
- «Se ha esfumado esa esencia que yo tenía.» (foros24h)
- «Ando todo el día triste, sin ganas de nada.» (foros24h)
- «Siempre he tenido un dolor en el alma, aunque siempre estoy sonriendo como tonta.» (Carmen Martín)
- «Estoy harta de todo, es siempre lo mismo. Todo me sale mal.» (foros24h)

**Lo que hacen para taparlo**
- «Cuanto más me miro, más ansiedad me entra y más como.» (weloversize)

**Abel, con sus palabras (misma época)**
- «Hecho una mierda.» · «Amargado todo el día.» · «Me ponía de mala hostia.» · «Muy rayado.» · «Me sentía fatal.» · «Buscaba el valor fuera.»

## Regla para escribir
1. Cada frase debe poder decirla alguien **en voz alta a un amigo, en un bar**. Si suena a taza o a póster, se reescribe.
2. Mejor una **escena** («lloro en la ducha para que no me oigan») que una abstracción («siento un vacío interior»).
3. La creencia necesaria se escribe como la diría esa misma persona **un día que está algo mejor**: llana, sin poesía.

---

# ARCHIVO: COMO-LO-EXPLICO.md

# Cómo lo explica Abel (leer antes de cualquier guion)

Fuente: sus explicaciones del 18/10/2026. Complementa «Mi forma de verlo» de `00-avatar-operativo.md` y las 10 áreas de `metodo-unidad.md`.

**Regla:** cuando llegue un guion o una transcripción base (un viral de otro), de ella se queda la estructura y el ritmo. Lo que no encaje con su explicación se cambia por la suya, sin ser drástico: el resto del texto se mantiene, y no hace falta nombrar la autoestima en cada guion (se sobreentiende). Los datos de un viral que nadie ha comprobado (los «17 segundos») no se dan como hechos.

**Profundidad:** en reels para público frío, todo aterrizado a escenas del día a día. Lo más profundo (la muerte, las vidas pasadas, Dios, «el miedo no es real») va en YouTube, sobre todo en documentación, o cuando el vídeo lo pide.

## 1. Primero lo que sientes: la emoción manda
- **La mente y los pensamientos sirven para operar en el juego**, en la vida: saber si algo está bien o mal, saber que esto es un teléfono y esto un libro, y hacer cosas.
- **Lo principal es la emoción**, porque el corazón está conectado con otra dimensión: con tu yo superior o con tu niño interior, ya vayas al pasado o al futuro.
- **Esa emoción tiene una energía.** Según cómo te sientes cambian tu energía y tu frecuencia, y por eso conectas con unos pensamientos o con otros.
- **Cambiar cómo te sientes a base de pensamientos es imposible:** tendrías que estar siempre en guardia. La emoción está conectada con el «inconsciente» (tu campo de energía) y es la que siempre manda.
- («Lo que piensas crea lo que sientes» era de un viral; no es su explicación.)

## 2. Las emociones son energía
- Se guía por el mapa de conciencia, pero **nunca nombra a Hawkins**.
- **Por debajo, energía baja o «más densa»:** vergüenza, culpa, apatía, tristeza, miedo, deseo, rabia y orgullo.
- **Por encima, energía alta:** valentía, aceptación, amor y paz.
- Palabras que usa: «energía baja», «energía más densa», «tu tasa de energía».

## 3. El miedo
- Es energía densa, baja, como la vergüenza o la apatía.
- Muchas veces la persona **no lo llama miedo**: «no quiero salir en cámara», «ya lo haré», «no me apetece». Pero es miedo, y hay que decírselo.
- **En lo más profundo, el miedo no es real** (lo explica como suyo; nunca se nombra *Un curso de milagros*). La verdad es el amor: todos somos amor. El miedo es una interpretación, una prueba falsa a la que le das valor y que te acabas creyendo.

## 4. Lo que llaman «inconsciente» es tu campo de energía
- **De lo más denso a lo menos:** el cuerpo es lo más denso; luego está el campo de energía, que es lo que la gente llama inconsciente. Son dos formas de explicar lo mismo.
- **Lo que haces en automático** («es un hábito heredado», «es una creencia», «lo hace mi inconsciente») viene de emociones que se quedaron dentro de tu campo de energía. Casi siempre son de situaciones de la infancia en las que no procesaste lo que sentiste.
- **Desde el cuerpo** se entienden las sensaciones y algunas enfermedades. **Verlo como energía** lo puedes aplicar a muchas más cosas de tu vida.
- **Las vidas pasadas** solo salen cuando se va muy en profundidad, nunca con público frío.

## 5. Cómo se sube la energía
1. **Escuchar la emoción y dejar de huir de ella.** Huir es el alcohol, el móvil, la procrastinación, todo lo que haces para evadirte. Aceptar la situación en la que estás es aceptar la emoción.
2. **Dejar que se exprese**, que es lo que de verdad significa «soltarla». La energía tiene información: cuando se expresa, te das cuenta de todo lo que has ido aguantando durante toda tu vida.
3. **Aprender de ella.** No basta con soltarla, que es lo que dice todo el mundo; esta es su diferencia.
4. **Aprender a pensar y a imaginar bonito.** Pide introspección y formación. Se mira:
   - en qué te centras: si ves las noticias o no, de qué hablas en una conversación, qué crees de la realidad;
   - qué hábitos tienes, desde qué intención los haces y cuáles son tus prioridades.
5. **Una rutina para enfocarte en emociones altas:**
   - **unos 5 minutos de silencio al día.** En silencio no hay pensamientos que te distraigan, y se crea coherencia entre el corazón y la cabeza;
   - **cumplir tu palabra**, que es ser congruente entre lo que piensas, lo que dices y lo que sientes.
6. **La energía sexual** es una energía inteligente: potencia todo lo que tienes.

La energía es un cúmulo de todo eso (emocional, física, lo que piensas, sexual… las 10 áreas del Método Unidad). Por eso se trabajan varias áreas a la vez.

## 6. Cómo sabes que avanzas
- **El medidor siempre es lo de dentro:** aunque fuera no haya cambiado nada, cada vez te sientes más en paz y más libre. Solo lo puede comprobar la propia persona.
- **Lo de fuera no demuestra nada.** Mucha gente justifica que ha crecido espiritualmente o en conciencia por lo que ha conseguido fuera, y no es así.

## 7. El nivel de verdad
- En cualquier formación, libro o cosa que aprendas, lo importante es **su nivel de verdad**: la verdad más profunda y absoluta.
- **Ejemplo:** la muerte no existe, porque es un cambio de frecuencia y de energía. Eso es la verdad. Puedes creer que existe o que no, pero eso no hace que deje de ser verdad.
- **Ampliado en el punto 14** (qué es la Verdad, cómo se reconoce).

## 8. El amor
- **No es el amor romántico** de sacrificarte por el otro, de apegarte, del «yo no puedo vivir sin ti».
- **El amor es congruencia interior.** Es haber sanado las emociones que te hacían actuar y decir las cosas de cierta manera.
- **Y es ser congruente al dar:** si sé que aportándote algo te puedo ayudar cuando me lo pidas, perfecto.

## 8b. Psicólogo y marca personal (cómo lo responde)
- **El psicólogo** te ayuda a entender lo que te pasa, pero puedes entenderlo todo y seguir repitiendo lo mismo; él lo vivió (fue a psicólogos y seguía igual). Lo suyo es sentir y cambiar cómo vives, no solo entender.
- **Marca personal:** tú eres tu marca personal. Tengas negocio o no, siempre te estás vendiendo.

## 8c. Cómo responde a las objeciones (Abel 18/10/2026, con sus palabras)
- **«997 € es mucho / no tengo dinero para invertir en mí»:** entonces no estás preparado. No estás conectado con tu abundancia, tienes miedo. Es una inversión, no un gasto: lo que inviertes en ti te lo quedas para siempre. El miedo real es no saber si serás capaz de hacer que valga la pena.
- **«¿Por qué tú, si no eres psicólogo?»:** porque he pasado por todo: psicólogos, terapia Gestalt, EMDR, terapia del inconsciente, constelaciones familiares, reiki, tarot, registros akáshicos. Y sé al 100 % que puedes entenderlo todo y no cambiar. El tema no está en la mente, está en las emociones: van siempre primero.
- **«La espiritualidad y lo de la energía son humo»:** no te voy a convencer de nada. Todos somos energía, lo creas o no. Si no lo ves es porque no has tenido el dolor suficiente para replantearte tu vida, por qué sientes lo que sientes o por qué atraes siempre al mismo tipo de persona. Y no, las casualidades no existen.
- **«No tengo tiempo para trabajarme»:** perfecto, si tus prioridades son cosas que no te hacen sentir bien y eres esclavo de lo que dicen los demás y de lo «correcto». Cuando entiendes la importancia de trabajarte por dentro, tu vida despega, porque todo lo atraes desde dentro.
- **«Ya lo he intentado todo y nada funciona»:** nadie va a hacer el trabajo por ti. Cuando hayas tocado fondo lo suficiente y tengas hambre de verdad, hasta el método más sencillo te funcionará. No es el método, es tu creencia, como el placebo: no es la pastilla, es que crees que te vas a curar.
- **«¿Cuánto se tarda en notar algo?»:** nunca da tiempos. Hay quien ejecuta cada día porque tiene hambre de cambiar, y quien paga y espera que alguien le arregle la vida sin hacer nada. No es cuánto se tarda, es cuánto estás dispuesto a hacer.

## 9. No salvas a nadie
- No cambias a nadie: es la otra persona la que se da permiso para cambiar.
- Tú solo das las herramientas, o haces de espejo.

## 10. El entorno eres tú
- Mucha gente critica su entorno, pero el entorno son las partes de ti que rechazas.
- **El amor incondicional** es amor por todas las situaciones y por todas las personas.

## 11. Dios
- **Elevar tu nivel de conciencia** es, por lo general, elevar tu emoción de forma sostenida. Al hacerlo cambian tus creencias sobre Dios.
- **Al principio** crees que Dios castiga y que elige a unos sí y a otros no.
- **Cuando llegas al amor incondicional** trabajándolo en ti, te das cuenta de que Dios toma a todas las personas del mundo como sus hijos.
- **Ejemplo:** si fueras padre de dos hijos, uno que se porta mal y otro que se porta bien, los querrías igual, y si tuvieras que elegir, no elegirías solo a uno. Eso es el amor incondicional.

## 12. Mecanismos para sanar (de dónde salen las SOLUCIONES; Abel 19/10/2026)
Su base es *El libro de Urantia* (y a Napoleon Hill para la energía sexual), pero **nunca se nombra el libro ni sus documentos**. En reels y guiones virales, cada mecanismo se cuenta bajado a tierra, como una solución que se puede aplicar hoy. Jesús, Dios, la oración y la adoración, solo en el contenido profundo (YouTube, documentación), según el punto 7 de arriba.
1. **Entender lleva a amar, y amar ya es haber perdonado.** Entiendes a quien te hizo daño → al entenderlo lo amas → si lo amas, ya lo has perdonado. Cuanto menos entiendes a alguien, más lo resientes. Como un padre sabio que ve los errores de su hijo pequeño y casi no tiene nada que perdonar. No es justificar lo que hizo, es verlo desde arriba: un padre asustado que repetía lo que le hicieron y no sabía hacerlo mejor. La herida pierde fuerza porque cambia el significado de lo que pasó.
   - Bajado a tierra: «la próxima vez que te acuerdes de él, pregúntate qué miedo tenía él para hacer lo que hizo».
2. **No luchar contra lo malo, desplazarlo con algo mejor.** Un mal hábito o una herida no se vence a base de fuerza de voluntad: se reconoce con honestidad y esa misma energía se dirige a algo más alto. Cuando amas algo mejor de verdad, lo viejo pierde el agarre y se va solo. Es lo mismo que con la energía sexual: no reprimir, canalizar.
   - Bajado a tierra: «deja de pelearte con el "no soy suficiente" y mete esa energía en algo que ames: un proyecto, ayudar a alguien; la herida se queda sin gasolina».
3. **El descanso del alma (la «adoración»).** No es un ritual: es un estado en el que te olvidas de ti, se relaja la tensión de vivir, baja el miedo y se va la sensación de estar solo. Es la seguridad profunda en la que el sistema nervioso se calma y lo enquistado se puede soltar («no se haga mi voluntad, sino la tuya»).
   - Bajado a tierra: los 5 minutos de silencio sin buscar nada (punto 5), rendirte a lo que no controlas.
4. **Orar por los demás.** Orar no es pedir cosas: es cambiar tu voluntad por una más alta. Mirar por los demás es el antídoto contra darle vueltas a tu dolor: quien se pasa el día rumiando se encierra más.
   - Bajado a tierra: «cuando lleves un día dándole vueltas a lo tuyo, haz algo por otra persona; mirar hacia fuera rompe el bucle».
5. **Compartirlo con alguien.** Contar lo que piensas a alguien de confianza te protege de ver las cosas deformadas, y el dolor y las derrotas duelen menos compartidos (iban de dos en dos).
   - Bajado a tierra: «cuéntaselo a una persona, solo a una; lo que dices en voz alta pesa menos».

## 13. El miedo y cómo se disuelve (Abel 19/10/2026; base Urantia, nunca se nombra)
- **Qué es:** el miedo es lo que más esclaviza a una persona, una herencia del animal que fuimos; el miedo sin razón es un engaño que se le hace al alma. **Detrás de mucha rabia hay miedo:** el odio es la sombra del miedo, y la venganza, la máscara de la cobardía. Junto con la ira, la envidia y la sospecha, bloquea lo que hay de Dios dentro de ti.
- **Qué lo disuelve: la CONFIANZA, no la lucha.** Se va cuando sabes que el universo es amigo y que no estás solo. La duda tambalea, pero la confianza viva vence.
- **La imagen (para contarlo):** la mayoría de la gente es como un niño perdido que llora de miedo y está a dos pasos de casa. El peligro no es real, el niño no sabe que está a salvo, y quien conoce el camino tiene que guiarle. Por eso el miedo no se cura convenciendo a nadie de que no hay peligro, sino ayudándole a SENTIR que no está solo y que está a salvo.
- **Cómo encaja con la psicología:** una herida sana cuando la emoción se activa, la persona se siente segura y vive algo que contradice lo que aprendió. Lo espiritual da la seguridad más profunda («nunca has estado solo, eres amado sin condiciones») y la experiencia contraria más potente a «no soy suficiente».

### Ejercicios (para el 1:1, YouTube y documentación; en reels, bajados a tierra y sin lenguaje religioso)
1. **Mirar la herida desde arriba (perdón por comprensión):** cierra los ojos, trae a quien te hirió, nota dónde lo sientes en el cuerpo y quédate ahí sin forzar; pregúntate qué miedo o qué herida llevaba esa persona, qué le hicieron a ella; mírala como un padre sabio ve a su hijo pequeño. No hace falta perdonar a la fuerza: observa qué cambia en el cuerpo al entenderla. Señal: el nudo se afloja.
2. **El descanso del alma:** 10-15 minutos a solas, en silencio, sin pedir ni analizar nada, contemplando algo más grande que tú; si salen emociones, déjalas estar; acaba con «no se haga mi voluntad, sino la tuya». (Es su práctica de silencio con la intención puesta en esa conexión.)
3. **El niño perdido cerca de casa (para el miedo):** cuando aparezca, no huyas, nota dónde está en el cuerpo, date cuenta de que estás a dos pasos de casa, de que no estás solo, y deja que se exprese sabiendo que estás a salvo hasta que pase. (Es lo que hizo Abel con su ataque de ansiedad: confiar en que la emoción no le iba a matar.)
4. **Desplazar con un amor nuevo:** identifica la herida o el hábito («no soy suficiente»), no luches contra él, elige cada día un acto concreto de bondad o algo que ames hacer, y cada vez que aparezca la herida, vuelve a eso.
5. **Desear el bien a otro cuando te hundes:** cuando estés dándole vueltas a tu dolor, para y desea de verdad el bien a otra persona que también sufra. Rompe el bucle.
6. **La revisión de cada noche:** «¿Hoy he sido más bueno, más paciente y más tolerante que ayer?». No para juzgarte, para ver tu crecimiento con perspectiva.
7. **No hacerlo solo:** comparte el proceso con alguien de confianza (pareja, amigo, compañero de camino).

### El orden con una persona (ejemplo de «Marcos», herida con su padre)
1. Seguridad primero: no forzarle a llorar ni a gritar; recordarle que no está solo y que es querido tal como es (el niño cerca de casa).
2. Que sienta la herida en el cuerpo, con calma, a su ritmo.
3. Que mire a su padre con comprensión (ejercicio 1): el hombre asustado que había detrás.
4. Descanso del alma (ejercicio 2), para que su sistema se calme y lo enquistado se suelte solo.
5. Desplazar con un amor nuevo (ejercicio 4).
6. Compartirlo con alguien y, cuando se hunda, desear el bien a otros.
7. Con el tiempo el miedo se va, porque ya no vive como un niño perdido, sino como alguien que sabe que tiene casa.

## 14. Qué es la Verdad (Abel 19/10/2026; base Urantia, nunca se nombra)
- **Tres niveles que se suelen mezclar:**
  1. **El conocimiento:** los hechos, lo que se mide y se comprueba.
  2. **La sabiduría:** el significado de esos hechos y cómo se relacionan.
  3. **La Verdad:** una realidad espiritual que solo se conoce viviéndola. No cabe en palabras.
- **Ejemplo (el que más le sirve a su cliente):** a una persona su padre se fue de casa cuando tenía 8 años.
  - Hecho: «mi padre se fue cuando tenía 8 años». No le dice nada de su vida.
  - Sabiduría: «por eso me cuesta confiar y tengo miedo a que me abandonen». Lo entiende, pero sigue sufriendo.
  - Verdad: «mi valor nunca dependió de que mi padre se quedara; soy amado tal como soy y nunca he estado solo». Cuando no lo piensa sino que lo SIENTE y lo vive, su vida cambia y deja de buscar desesperadamente que nadie la abandone.
  - Es la diferencia entre saberse la receta y probar el plato. (Es lo mismo que dice Abel del psicólogo: entender no basta.)
- **La Verdad está viva:** si se encierra en reglas o fórmulas, se muere y se vuelve teoría. Ejemplo: «hay que perdonar» puede volverse una losa («si no perdono, soy mala persona»); la Verdad viva es entender al otro tan a fondo que el perdón sale solo, cuando estás preparado (punto 12). Cada persona la vive desde su lugar.
- **Cómo reconocerla (prueba práctica):**
  1. **Se puede vivir:** si una idea suena muy bien pero al vivirla te deja vacío o frustrado, no es Verdad; si al vivirla te sientes más libre y en paz, sí.
  2. **Tiene «sabor»:** algo dentro de ti la reconoce, la sensación de «esto ya lo sabía, aunque nunca lo había oído así».
  3. **Va con la belleza y la bondad:** ¿encaja con todo lo que sé y vivo? (verdad), ¿me inspira, tiene algo hermoso? (belleza), ¿me hace bien a mí y a los demás? (bondad). Si falla una, desconfía. La salud, la cordura y la felicidad aparecen cuando las tres están en tu vida.
  4. **Se hace tuya con la fe,** apoyada en la reflexión, la autocrítica honesta y la conciencia. Descubrirla por ti mismo es la mayor alegría del alma.
- **Los errores con la Verdad:** convertir la ciencia en doctrina, la filosofía en sistemas rígidos y la Verdad en dogma, por pereza mental y por miedo a lo desconocido. Quien defiende su método como «la única verdad» y ataca todo lo demás suele tener miedo detrás.
- **Uso:** en reels, bajado a tierra (receta vs. plato, el ejemplo del padre sin lenguaje religioso, la prueba de «¿te deja en paz o vacío?»); lo espiritual entero, en YouTube y documentación.

---

# ARCHIVO: BANCO_IDEAS_YOUTUBE.md

# Banco de ideas de YouTube (desde 18/10/2026)

> Todas apuntan a la persona de `01_MI_MARCA/00-avatar-operativo.md` (Especialista en Autoestima) y cuelgan de una rama del tronco de la rutina diaria.
> Las de marca personal están en `_ARCHIVO_MARCA_PERSONAL/` y NO se usan.

## Principal
- ✅ (19/10) Dejar de ser complaciente: la energía que pierdes con cada sí que no sientes (3 excusas, rama 2).

## Energía sexual
- ✅ (19/10) Recuperar tu energía sexual: recaer es una emoción pidiendo salida; canalizar en vez de apretar los dientes (3 pasos).

## Documentación
- ✅ (19/10) «Lo mío me lo trago»: de los 10 años al ataque de ansiedad a los 19 en el borde de la cama (rama 4).

---

# ARCHIVO: creencias-y-frases-de-batalla.md

# MIS CREENCIAS Y FRASES DE BATALLA (versión de Abel)

> Dictadas por Abel el 2026-10-05. **Esta versión manda sobre la lista del doc 04.**
> Las frases de batalla son SUS palabras, solo limpiadas. No se reescriben "más bonitas": si hace falta adaptarlas a un guion, se mantienen sus expresiones.
> Son afirmaciones, no "puede ser". Generan hate en quien piensa lo contrario, y está bien.

## C1 · La muerte no es real
**Lo que pienso:** la muerte no es el final. Y nadie es ateo de verdad: cuando una persona está jodida y lo ha perdido todo, ahí es cuando busca ayuda en Dios o en algo superior.
- **FB-C1a:** La muerte no es real.
- **FB-C1b:** No hay nadie que sea ateo. Cuando estás jodido y lo has perdido todo, ahí es cuando buscas ayuda en Dios.

## C2 · Vivir esperando al viernes
**Lo que pienso:** debajo está creer que tu valor como persona está en cuánto tienes o en cuánto eres capaz de hacer. Si vives esperando al viernes o a las vacaciones, es porque no tienes una vida que te guste vivir y eres esclavo de lo que "habría que hacer".
- **FB-C2a:** Si vives esperando al viernes o a las vacaciones, es porque no tienes una vida que te guste vivir.
- **FB-C2b:** Te has creído que vales lo que tienes o lo que eres capaz de hacer.

## C3 · El ego espiritual
**Lo que pienso:** el ego espiritual es mucho más jodido que el normal. Hay gente "espiritual" que se cree iluminada y lo usa para sentirse superior a los demás.
- **FB-C3:** El ego espiritual es mucho más jodido. Hay gente que se cree iluminada y lo usa para sentirse superior a los demás.

## C4 · Ser complaciente no te hace buena persona
**Lo que pienso:** el amor no es decir que sí a todo para quedar bien. Amar es decir la verdad cuando sabes que puede ayudar.
- **FB-C4a:** Ser complaciente no te hace buena persona.
- **FB-C4b:** El amor no es decir que sí a todo. Es decir la verdad cuando sabes que puede ayudar.

## C5 · El desarrollo personal
**Lo que pienso:** mucho desarrollo personal es desarrollar un personaje que te has creado para que te acepten en la sociedad. Se ha convertido en una muleta o en un hobby, en vez de entender lo que es conocerte de verdad.
- **FB-C5a:** El desarrollo personal es desarrollar un personaje que te has creado para que te acepten.
- **FB-C5b:** Has convertido el desarrollo personal en una muleta o en un hobby, en vez de conocerte de verdad.

## C6 · Espiritualidad y ambición
**Lo que pienso:** hay gente que cree que si eres más espiritual, o vas más "de energías", pierdes la ambición y te sales del mundo. No es así: lo que pasa es que entiendes desde dónde tienes que hacer las cosas.
- **FB-C6:** Ser espiritual no te quita la ambición ni te saca del mundo. Te hace entender desde dónde tienes que hacer las cosas.

## C7 · Lo que consumes te condiciona
**Lo que pienso:** la gente no es consciente de que todo lo que ve y escucha le condiciona el inconsciente. Se justifica con frases normales del día a día y no ve lo que le está metiendo dentro:
- «Voy a ver una peli de miedo» → te estás metiendo miedo.
- «Voy a ver las noticias para informarme» → no te estás informando, te estás envenenando.
- «Voy a escuchar reggaetón» → al final estás escuchando canciones que denigran a la persona, una y otra vez.
- Y lo mismo con el contenido hipersexualizado del móvil.

- **FB-C7a:** No eres consciente de que todo lo que ves te está condicionando el inconsciente.
- **FB-C7b:** No te estás informando, te estás envenenando.
- **FB-C7c:** Escuchas reggaetón todo el día y al final estás escuchando cómo se denigra a la persona.

## C8 · Quejarse sin querer cambiar *(nueva)*
**Lo que pienso:** hay mucha gente que se queja de su situación pero no quiere cambiar: lo que quiere es ser el centro de atención. A esa persona no te toca salvarla (transcripción 02). Ojo: NO es quien pide ayuda de verdad.
- **FB-C8:** Hay mucha gente que se queja de su situación, pero no quiere cambiar. Quiere ser el centro de atención.

## Frases de mis transcripciones
- **FB-T03:** Si solo buscas lo barato, tu vida será barata.

---

# ARCHIVO: afirmaciones.md

# REGISTRO DE AFIRMACIONES — lo que ya he dicho en público

> Cada guion aprobado añade aquí sus afirmaciones de fondo (lo que defiende, lo que critica, lo que recomienda).
> Antes de escribir cualquier guion nuevo se revisa este registro junto con `correcciones.md` y `creencias-y-frases-de-batalla.md` (C1-C8), que son posturas fijas aunque aún no se hayan publicado.
> **Ningún guion puede contradecir algo de aquí.** Si una idea nueva choca, se avisa a Abel ANTES de escribir y decide él:
> matizar el guion nuevo, o actualizar la postura (y entonces se anota aquí qué cambió y por qué).

## Posturas por tema

_Las 8 creencias de `creencias-y-frases-de-batalla.md` son posturas fijas desde ya. Aquí se apunta lo que cada guion afirma en concreto._

### Consumo, móvil y lo que entra por los ojos
| Afirmación | Matiz importante | Guion |
|---|---|---|
| Lo que consumes antes de dormir (móvil, vídeos, noticias) te afecta al día siguiente | No digo que el móvil sea malo; digo que lo que entra se queda | G-001 |
| Tu cuerpo no distingue si algo lo ves en un vídeo o te pasa a ti: para él es miedo | Dicho como convicción, no como dato científico | G-001 |
| Lo que entra se queda, y lo que se queda es lo que emites | Base de la creencia C7 | G-001 |
| Ver las noticias «para informarte» no te informa, te envenena | Postura C7. Coherente con G-001 (las noticias te llegan solas por el móvil) | C7 |
| Las letras de muchas canciones (reggaetón) denigran a la persona y eso también se te queda dentro | Postura C7. Se critica el contenido, nunca a quien lo escucha | C7 |
| Recomiendo probar una semana dejando el móvil fuera de la cama | Propongo una prueba concreta, no prohibiciones ni cambiarlo todo | G-001 |

### Energía e invisible
| Afirmación | Matiz importante | Guion |
|---|---|---|
| La energía de la que habla la gente a diario («hoy no tengo energía») es algo de verdad | Se planta la pregunta, sin explicarla todavía | G-001 |

### Trabajo
| Afirmación | Matiz importante | Guion |
|---|---|---|
| El trabajo puede ser parte del problema ("y puede ser, ¿eh?") | No niego el estrés del trabajo; digo que hay otra capa | G-001 |

### Ayudar a los demás
| Afirmación | Matiz importante | Fuente |
|---|---|---|
| No te corresponde salvar a quien no quiere cambiar | Se refiere a quien dice que necesita ayuda pero solo busca atención y que validen su victimismo. NO a quien pide ayuda de verdad (pedir ayuda es inteligente) | T02 |

### Emociones (guiones de referencias, 10/10/2026)
| Afirmación | Matiz importante | Guion |
|---|---|---|
| La ansiedad no es el problema; el problema es no dejarte sentir | Si tapas lo que duele, tapas también la alegría y las ganas | Ref. Quinlan Walther |
| Explicarte de más viene de la infancia (nadie te escuchaba / te hicieron responsable de los demás) | Coherente con C4 (complacencia) | Ref. Vassia Sar |
| No se trata de controlar lo que sientes, sino de dejar de pelearte con ello y sentirlo | La emoción va primero; la cabeza se calma después | Ref. drcoachrees |
| Los celos no son amor, son miedo a que no te elijan | Cada emoción trae un mensaje; tragártela te aleja de ti | Ref. candasifamabarnes |
| Tu cuerpo sabe lo que sientes antes que tu cabeza; no notar nada es estar desconectado | Dónde se nota cada emoción, dicho como experiencia («casi siempre»), no como ciencia | Ref. its.jaygomez |

## Cambios de postura
| Fecha | Antes decía | Ahora digo | Por qué |
|---|---|---|---|
| | | | |

---

# ARCHIVO: _indice-banco.md

| ID | Nivel | Bloque | Título |
| B-017 | 1 | Nivel 1-2 — Masculinidad, autocontrol y energía sexual (conexión con Gran Arcano) | Lo que tú llamas control es evitación, y por eso vuelves a caer cada 10 días. |
| B-018 | 1 | Nivel 1-2 — Masculinidad, autocontrol y energía sexual (conexión con Gran Arcano) | Recaer no es falta de disciplina, es una emoción pidiendo salida por el único canal que le dejas abierto. |
| B-019 | 1 | Nivel 1-2 — Masculinidad, autocontrol y energía sexual (conexión con Gran Arcano) | Te comparas con hombres que sientes “de otra raza” y esa comparación es exactamente lo que te mantiene lejos de ellos. |
| B-020 | 2 | Nivel 1-2 — Masculinidad, autocontrol y energía sexual (conexión con Gran Arcano) | Apretar los dientes no te hace más hombre, y lo contrario tampoco. |
| B-021 | 2 | Nivel 1-2 — Masculinidad, autocontrol y energía sexual (conexión con Gran Arcano) | Tu energía sexual y tu capacidad de construir salen del mismo sitio, y nadie te lo había dicho con esta claridad. |
| B-022 | 2 | Nivel 1-2 — Masculinidad, autocontrol y energía sexual (conexión con Gran Arcano) | Te crees que hablar de lo que sientes te hace menos hombre, y es exactamente al revés. |
| B-023 | 2 | Nivel 1-2 — Masculinidad, autocontrol y energía sexual (conexión con Gran Arcano) | Que ella no te eligiera no hablaba de ti, hablaba de la frecuencia desde la que te acercaste. |
| B-024 | 3 | Nivel 1-2 — Masculinidad, autocontrol y energía sexual (conexión con Gran Arcano) | No te falta fuerza de voluntad para controlarte, te falta algo que nadie te ha enseñado. |
| B-025 | 3 | Nivel 1-2 — Masculinidad, autocontrol y energía sexual (conexión con Gran Arcano) | Puedes dejar todos tus vicios y seguir con el problema real intacto, y eso es lo que no te han dicho. |
| B-026 | 3 | Nivel 1-2 — Masculinidad, autocontrol y energía sexual (conexión con Gran Arcano) | Ocultas cuando pierdes el control y eso te está costando más que el propio descontrol. |

---

# ARCHIVO: mi-voz.md

# MI VOZ — cómo hablo

> Sacado de 4 transcripciones mías (`transcripciones/01-04`). Se amplía cada vez que entren más.

## ⭐ ANÁLISIS DE 6 VÍDEOS DE YOUTUBE (10/10/2026): ESTO MANDA PARA SONAR A ABEL

Fuentes: 3 vídeos de Héroe Viaje (retención) y 3 de abelunidad, 97 min y 17.565 palabras (`transcripciones/youtube/`), más 29 min de sus vídeos de emociones.

**Ritmo.**
- Unas **3 palabras por segundo** contando las pausas: calmado, explica sin prisa.
- Tramos de unas 10 palabras entre respiraciones.
- Frases largas encadenadas, no telegráficas.

**Las palabras que más usa (por orden):**
1. **«tú»** (265): siempre le habla a la persona, a menudo con el «tú» explícito y repetido: «cuando tú», «si tú», «tú te tienes que sentir…».
2. **«porque»** (211): justifica todo.
3. **«pero»** (136).
4. «realmente» (58).
5. «cuando tú» (48).
6. «entonces» (44).
7. «es que» (38).
8. «sabes» (31).
9. «tienes que» (30).
10. «si tú» (28).
11. «¿vale?» (26).
12. «o sea» (24).
13. «por tanto» (24).
14. «¿de acuerdo?» (22).
15. «por ejemplo» (20).
16. «al final» (17).
17. «ok» (15).
18. «digamos» (14).
19. «lo más importante» (13).
20. «imagínate» (11).
21. «simplemente» (11).

Casi NO usa: «mira», «fíjate», «tío», «literalmente».

**Cómo arranca:** con una afirmación rotunda dirigida a ti, sin presentarse.
- «La única forma que tienes para manifestar la vida que tú quieres es a través de la acción. Así que deja de estar mirando vídeos, mirando podcast, escribiendo 850 afirmaciones en tu libreta y ponte a trabajar.»
- «Te estás resistiendo a aquello que te está pasando en tu vida…»
- «Un hombre sin propósito está desconectado de su masculinidad por completo.»

**Cómo desarrolla (sus recursos de verdad):**
1. **Se pregunta y se responde:** «¿Por qué digo esto? Porque…», «¿Por qué quiero hacer este vídeo? Porque…», «¿En quién te tienes que centrar? En quién eres tú.»
2. **Diálogos internos de la persona, en voz alta:** «ya, pero es que tal persona ha hecho algo…», «ok, esto ha pasado, ¿lo preferiría? Claro que lo preferiría…», «joder, y si atraigo a mujeres, pues mejor que mejor», «sí, sí, pero espabila, que aquí hay que accionar».
3. **Exageración concreta con humor:** «escribiendo 850 afirmaciones en tu libreta», «hasta las tantas viendo vídeos».
4. **Anáforas y enumeraciones:**
   - «quien hace el negocio es la persona, quien tiene ansiedad es la persona, quien tiene miedos es la persona»;
   - «en modo lucha, en modo sacrificio, en modo supervivencia, en modo estrés».
5. **Se adelanta a la objeción:** «Yo no digo que el conocimiento no sea necesario, por supuesto…», «aunque parezca muy Mr. Wonderful, te aseguro que…».
6. **Se corrige al hablar, matizando:** «no es que no sirva, sino que no siente que sirve», «no predicciones, sino tiradas de tarot… no, más profundo».
7. **Remata con seguridad total:** «te aseguro que», «al 100 %», «absolutamente nada», «todos y cada uno».
8. **Pide confirmación:** «¿vale?», «¿de acuerdo?», «¿verdad que no?».
9. **Su prueba, sin adornos:** «es algo que a mí durante mucho tiempo me ha pasado. Yo era una persona muy mental».
10. **Su vocabulario:** «espabila», «joder», «como Dios manda», «un machete para ir derribando creencias», «si eres sincero y honesto contigo», «lo más importante de todo».

**Cómo cierra:** «Así que…» más la idea resumida en una frase. En YouTube después viene el CTA y «chao, chao»; en los reels, nada de CTA.

**🚫 NUNCA en lo que escriba con su voz (Abel 10/10/2026):**
- «¿vale?» y «¿de acuerdo?»: «conectores que no ayudan en nada»;
- «¿Por qué digo esto? Porque…» y similares: «es como si pidiera permiso para decir lo que realmente sé».
Él los dice al hablar, pero no los quiere. Se afirma directo. Si salen al grabar, se cortan al editar.

**Para los reels (más cortos y directos que YouTube):**
- se quedan el arranque rotundo, un diálogo interno, la exageración concreta, «te aseguro», «realmente» y el cierre «así que…»;
- fuera las explicaciones largas con «por tanto», «es decir», «digamos».

## Principio nº 1: el guion sale del habla, no al revés

Mis vídeos son **habla convertida en texto**, no texto pensado para leerse. Por eso:
- **Una sola idea por vídeo.** Sin listas de puntos, sin "en primer lugar", sin secciones que se noten. Fluye de una frase a la siguiente.
- **Se graba sin esfuerzo:** si hay que memorizar una estructura, está mal. Tiene que poder decirse de un tirón entendiendo la idea.
- **Coloquial de verdad:** que no parezca escrito por nadie, y menos por una IA.

## Ritmo

- **Mezcla de frases largas que fluyen** (encadenadas con "y", "porque", "pero", "o sea") **y golpes cortos** que rematan: "Tú eliges." / "¡Pam! Este sí gana." / "Eso marca la diferencia."
- ⚠️ Esto **prevalece sobre la regla de las skills de "máximo 10 palabras por frase"**. Lo que importa es que se pueda decir de una respiración natural, no contar palabras.
- Polisíndeton en las tríadas: "ser amor **y** de inspirar **y** de hacer de cada lugar…", "no tener, no poder y matarte a trabajar".
- Repetición para martillear: "los más grandes cuentan historias, los más grandes conectan contigo, los más grandes transmiten el dolor…"

## Cómo empiezo (hooks)

**Hooks de reel (corrección de Abel, 2026-10-09):** crudos, directos, algo polémicos, que remuevan y paren el scroll. Son el 90% de que un reel funcione. El hook es una frase APARTE: se graba suelto y el cuerpo empieza después sin repetirlo (normalmente con «Porque…», «Y es que…» o directamente la escena). El cuerpo tiene que encajar detrás de cualquiera de los 3 hooks. El estilo de gancho se va afinando con lo que funciona en las referencias.


Siempre con una **verdad rotunda en la primera frase**, normalmente con un "si" condicional o un "tú" directo:
- "**Si** solo buscas lo barato, tu vida será barata."
- "**Si** no escucha, no aplica y no cambia, no lo ayudes."
- "**Tú** tienes que tocarle el dolor a la gente."
- "**Si** eres del nicho fitness, **fíjate en una cosa**: …"

Nada de introducciones, ni de "hola", ni de "hoy te voy a hablar de".

## Cómo desarrollo

1. **Amplío la verdad con "o sea"** o justificándola: "o sea, tú no puedes pretender…"
2. **Dramatizo conversaciones** con voces entre comillas: «Oye, ¿cuál es tu problema actual?» → "Mira, pues sufro con no sé qué…". Hago hablar a la otra persona.
3. **Pregunta retórica y me la respondo yo:** "¿Qué estoy haciendo? Te estoy haciendo ver que…" / "¿Pero por qué? Fíjate en una cosa…"
4. **Contraste con ejemplos concretos:** el que no gana dice esto, esto y esto; el que sí gana dice esto. ¡Pam!
5. **Me pongo como prueba, sin adornos:** "yo sé perfectamente qué es no tener… porque yo vengo de ahí" / "yo he vendido 5.000 euros".

## Cómo cierro

**Un reel NUNCA acaba en pregunta** (corrección de Abel). Acaba con un golpe final rotundo; la pregunta para comentar va en la descripción.

**Teleprompter:** leo el texto literal, así que tiene que leerse en voz alta sin trabarse: puntuación que marque dónde respiro, nada de frases que obliguen a releer.


Frase corta, rotunda, que devuelve la responsabilidad o resume la identidad:
- "Si tú no entras en el juego, nunca podrás ganar. **Tú eliges.**"
- "Entonces, **marca personal eres tú.** Escoge lo que quieres transmitir."
- Cierre desde lo espiritual-coherente: "Tú encárgate de ser amor… y sobre todo, de vivir en coherencia con tus valores."

## Expresiones y muletillas mías

- "o sea" · "vale" / "¿vale?" · "mira" · "fíjate en una cosa" / "fijaos en una cosa"
- "no sé qué, no sé cuántos" · "tal, tal, tal" (relleno oral cuando pongo ejemplos)
- "¡Pam!" · "es que…" · "obviamente" · "totalmente"
- "¿Tiene sentido lo que estoy diciendo?"
- "Y lo siento porque no es bonito de escuchar, pero es así, te lo prometo."
- "Y mira que yo sé perfectamente…" · "Y si no me creéis, haced el estudio vosotros."
- "Que no, ¿eh?" (me adelanto a la objeción)
- "eso lo cambia todo" · "eso marca la diferencia" (en mi boca sí suenan naturales: usar como mucho una vez)
- Tacos suaves cuando toca: "estás jodido".
- Hablo de **Dios** con naturalidad, como "ese poder que se encarga del proceso de todas las personas". Sin dogma.

## Frases de batalla

No son eslóganes ni frases de bar redondas. Son frases que digo yo hablando, sencillas, con mis palabras, como «Si solo buscas lo barato, tu vida será barata». Si suena a cartel motivacional o a juego de palabras ingenioso, es IA. Mejor sacarlas de lo que dicto que inventarlas.

## Cómo meto lo invisible

Por las **palabras que la gente ya usa a diario**: energía («hoy no tengo energía», «este sitio tiene mala energía»), corazonada, intuición, mala espina, «estamos en la misma onda». Una pregunta que le haga pensar en lo que dice sin darse cuenta («¿tú te has parado a pensar qué es eso de la energía que dices que no tienes?»). «Vibración» y «frecuencia» con todas las letras, solo en vídeos N3 o superiores.

## Tú / vosotros

Siempre **de tú a tú**, como si tuviera a la persona delante.

Uso **"tú"** casi siempre. Cambio a **"vosotros"** cuando me dirijo a un colectivo ("fijaos", "no os estáis dando cuenta", "haced el estudio vosotros"). Español de España.

## Lo que NUNCA hago

- **Ejemplos de su edad y género** (29 años, hombre; Abel 13/10/2026): gustos, referencias y ejemplos que diría él, sin sonar a colega. MAL: «mujeres de 40».
- **Español de España, nunca latino** (Abel 13/10/2026): «visitas», no «vistas»; «me gusta», no «like»; nada de «cagazo» (se dice «esto da miedo»). Ante la duda, cómo lo diría alguien de España.

- **Escenas que la persona no vive de verdad** (corrección de Abel). Test obligatorio de cada escena: ¿esto lo hace o lo siente la persona casi todos los días? Si no, se busca otra (el móvil en la cama, el café con el WhatsApp, el domingo por la tarde…). La conexión sale de describir su día a día y cómo se siente, como en `transcripciones/04`.

- **Tics de IA** (corrección de Abel): fragmentos cortados para crear efecto ("Siete noches.", "No. Una."), repeticiones enfáticas ("haz una cosa, solo una"), comas dramáticas ("se queda dentro, vibrando,"). Ojo: el banco B-xxx está escrito con ese estilo; se usa su IDEA, nunca su ritmo.
- **Palabras que la gente no entiende**: anglicismos o términos de nicho ("true crime"). Se dice como lo diría cualquiera: "películas de miedo", "series de asesinatos".

- Explicar teoría en lista ("los 3 alimentos…", "2 trucos para…"). Lo critico yo mismo: **"el que no gana escupe teoría todo el rato"**.
- Sonar a copy: nada de "descubre", "transforma tu vida", "potencial", "empoderar", "journey", "en la era de…".
- Estructuras escritas: paréntesis, punto y coma, "por un lado / por otro", "en conclusión".
- Pedir perdón por lo que digo: lo suavizo como mucho con "no es bonito de escuchar, pero es así".

## Plantilla mental de un vídeo mío (no se escribe con títulos en el guion)

**Verdad rotunda** → la amplío con "o sea" o un ejemplo → **escena o diálogo concreto** → pregunta "¿pero por qué?" y me la respondo → **mi prueba personal** → **golpe final corto**.

## 🔴 SIN RELLENO, PERO FLUIDO (Abel 18/10/2026)
Fuera todo lo que no añade información vital (repeticiones, muletillas, «y te lo digo claro», «así que»); el texto tiene que fluir y conectar como se habla, sin trocear frases.

---

# ARCHIVO: 02-catalogo-momentos-concretos.md

# 02-catalogo-momentos-concretos

> Fuente: 02-catalogo-momentos-concretos.pdf (convertido automáticamente; el PDF original está en fuentes/)

02-catalogo-momentos-concretos
ABEL · Catálogo de Momentos Concretos de Vida
Para la creación de contenido: elige uno distinto cada vez, nunca repitas el mismo momento en piezas seguidas.
Cómo usar este documento
Cada punto de abajo es un momento real, concreto y verificable de la vida de Abel — no una idea abstracta. Cuando el contenido de la pieza pida una referencia personal, busca aquí el momento que mejor encaje con la creencia u objeción de la que se está hablando (no el primero de la lista, no siempre el mismo). Varía la elección entre piezas: si dos descripciones seguidas usan el mismo momento, busca otro.
Si ningún momento de este catálogo encaja de verdad con el tema de la pieza, no inventes ni fuerces uno: pregunta a Abel algo como “¿me cuentas algo concreto que te pasara relacionado con [tema] para que la pieza conecte de verdad?” y espera su respuesta.
Regla de especificidad: cuanto más concreto el detalle (edad, cifra, lugar con nombre, hora, objeto), más conecta. “Perdí dinero apostando” conecta menos que “perdí 2.500€ en una noche apostando a partidos de ping-pong tirado en la cama”. Siempre que exista el detalle en el catálogo, úsalo.
Infancia y adolescencia
Separación de sus padres cuando era niño y mudanza de unos 700 km con su madre a un entorno completamente nuevo. Llegada a Castelldans a los 10 años, a vivir con sus tíos a las afueras del pueblo. Trayecto diario al colegio de 40-45 minutos de ida y otros 40-45 minutos de vuelta. Colegio nuevo sin hablar bien el idioma local; sufrió bullying durante esa etapa de adaptación. Pérdida de continuidad, pertenencia y seguridad tras la mudanza — tuvo que reconstruir su lugar en el mundo desde cero, de niño. Fallecimiento de su abuelo durante esta época de acumulación de golpes. Dificultades económicas en casa; comparación con familias que percibía como más estables. Aislamiento y soledad durante esos años de adaptación. Curiosidad de niño por entender por qué unas personas tienen autoestima y otras no, y cómo funcionan la mente, las emociones y el comportamiento — pista temprana del propósito que reconocería después. De pequeño corrió atletismo y ganó varias medallas; quedó tercero de toda Castilla y León en marcha atlética. Vivió un episodio de ansiedad de su madre en casa durante la infancia-adolescencia. De ahí nació la regla interna “lo mío me lo trago; no debo ser una carga” — aprendió, con 10 años, a guardarse los problemas para

no sumar peso en casa.
Primeros pasos en YouTube y contenido
Sus primeros vídeos los grabó jugando a Minecraft en casa; el canal todavía existe y se puede ver con su voz de entonces (“voz de pito”). Grababa y jugaba con un ordenador portátil que le regaló su padre al acabar la primaria. El ordenador se sobrecalentaba mucho al grabar y jugar a la vez; ponía dos pilas de libros debajo para que se airease y no se apagara — si se apagaba, perdía todo el progreso del mundo de Minecraft. Entre el canal de Minecraft y el canal de Clash Royale, también subió una temporada vídeos de desarrollo personal y psicología en otro canal, que después borró (conserva capturas de esa etapa). Pagó 900€ por el curso Crecetube de Romuald Fons; gracias a lo aprendido ahí creó el canal “Clap” (contenido de Clash Royale), que llegó a los 30.000 suscriptores durante la pandemia (el canal sigue subido). Ha asistido a algún evento como espectador, por ejemplo para ver a Álvaro Boscof, sin mayor repercusión — como parte de su propio recorrido de consumir contenido antes de crearlo al nivel de hoy.
Ansiedad y aprendizaje del silencio
Tuvo su propio ataque de ansiedad con 19 años. Lo pasó él solo, sentado en el borde de la cama, sin despertar a nadie en casa. Fiel a la regla “lo mío me lo trago solo” que llevaba grabada desde niño. Superó ese ataque simplemente confiando en que no se iba a morir y dejando que la emoción se expresara y pasara — sin resistencia. No fue una técnica aprendida: fue una rendición. Después entendió que eso era exactamente lo que las terapias llaman “sostener la emoción hasta que se procesa”. Por fuera parecía más controlado de lo que se sentía por dentro; asociaba fortaleza con aguantar y callar, no con sentir y procesar.
Mecanismos de evasión (época de mayor descontrol)
Videojuegos / Call of Duty como descarga de rabia y zona de confort. La etapa de mayor descontrol fue en 1º y 2º de la ESO: en 1º le pusieron siete partes y casi lo expulsan; en 2º casi repite curso porque suspendía casi todas las asignaturas. Empezó a jugar mucho al Call of Duty en esa época; se ponía de muy mal humor y llegó a romper varios mandos de consola. Pornografía y masturbación como anestesia emocional, sobre todo ante presión, ansiedad o soledad. Apuestas y alcohol como impulsividad y desconexión. En apuestas, llegó a perder 2.500€ en una sola noche apostando tirado en la cama a partidos de ping-pong — algo que él mismo describe como “ya enfermizo”. Relaciones rápidas usadas como refugio contra la soledad y el miedo al abandono. Adaptación social constante: moldearse para ser aceptado y evitar conflicto. Programa heredado directamente de la mudanza y el bullying de infancia. Compras e hiperconsumo como alivio temporal, ya con dinero. Consumo pasivo de contenido como anestesia: horas de series, scroll y vídeos; parte de ese consumo era contenido de alta carga

de miedo (noticias, pelis de terror) sin ser consciente del precio real que su sistema estaba pagando.
Trabajos y primeros pasos laborales (antes del éxito con YouTube)
Ayudante de camarero desde los 16 años, algunos fines de semana: 10-12 horas por unos 50€. Monitor de la campaña de Navidad en El Mestre (empresa de Lleida), en primero de carrera. Call center. Secretario de una cooperativa. Azafato de eventos (incluyendo alguna promoción de alcohol). Departamento de marketing digital en Rodi Motor Services (empresa fuerte de Lleida). Departamento de obras en Rodi Motor Services. Dejó el trabajo del departamento de marketing digital cuando empezó a generar más dinero con YouTube que con el empleo.
El punto más bajo (20-21 años)
Alrededor de los 20-21 años vivió el punto más bajo de su vida: una sensación de pura supervivencia, con el diálogo interno “mi vida no tiene sentido”, “he tenido muy mala suerte”, “¿por qué a mí?”. No fue un solo evento, sino la acumulación de pérdidas, cambios, ansiedad y falta de herramientas emocionales. En ese periodo llegó a un momento tan grave que no quería seguir vivo. Se puede referenciar con respeto y sin detalle, como el fondo real del que partió toda su transformación posterior — nunca como anécdota decorativa.
Búsqueda de valor externo y comparación
Persiguió dinero, éxito, físico, mujeres, fama, reconocimiento, seguidores, coche y casa como pruebas externas de que valía algo. Se comparaba con hombres que sentía “de otra raza” — más seguros, más masculinos que él — y esa comparación alimentaba rabia contra sí mismo. La necesidad de demostrar iba dirigida especialmente a su padre y a la familia paterna: quería poder decir “yo también puedo”. Relación con una mujer muy atractiva físicamente que funcionó como prueba externa de valor, aunque más tarde percibió en ella dinámicas narcisistas y poca disponibilidad emocional. Dependencia emocional en pareja: ceder más de lo que quería, comprar cosas para conservar el vínculo, vigilar el WhatsApp de forma obsesiva, angustiarse ante retrasos, imaginar que podía estar con otro, adaptarse hasta perder autenticidad. La frecuencia desde la que se acercaba a esa relación (necesidad, no deseo) era exactamente la que atraía esa falta de disponibilidad emocional en ella. Lo entendió años después.
El primer éxito
Llegó a 100.000 suscriptores y unos 17.000€/mes de facturación. Al empezar a ganar mucho dinero sintió una calma que después entendió que no era paz real, sino regulación emocional temporal — le duraba unas dos semanas antes de que volviera la ansiedad. Tras esa calma llegó un miedo intenso a perderlo todo: revisaba métricas y rendimiento de vídeos de forma compulsiva, y hacía compras innecesarias.

Se despertaba de madrugada con el corazón acelerado sin saber por qué, y a esa sensación la llamaba “estar espabilado” en lugar de ansiedad. Mientras tenía éxito por fuera, seguía subiendo contenido motivacional entre semana con la sonrisa puesta en cámara sin que nadie supiera lo que pasaba realmente por dentro de él. Cuando ganó mucho dinero con YouTube, les regaló a sus padres un viaje a Finlandia con todo pagado — era el sueño de su madre ver las auroras boreales, los huskies y el pueblo de Papá Noel.
La caída
Ruina económica, deuda con Hacienda, cierre de su empresa y una ruptura de pareja, todo prácticamente a la vez. Debía unos 3.000 y pico euros a Hacienda, más 1.500-1.600€ de cerrar su empresa. Crisis de identidad tras la caída: llegó a pensar “quizá tengo que aceptar una vida normal”. De esa misma crisis nació también la idea decisiva: “si lo hice una vez, puedo volver a hacerlo”. Ya se había comprometido y había dado la señal para pagar un curso de inglés en Australia (unos 10.000 dólares australianos en total); había pagado unos 3.000-4.000€ y le quedaba todo lo demás por pagar.
Australia y sudeste asiático
Empezó de cero en Australia sin red de seguridad, trabajando en múltiples oficios, incluido fregar platos. De friegaplatos trabajaba unas 7-8 horas, cobrando 20 dólares australianos la hora, en Brisbane. Fue precisamente ahí, sin nada que demostrar, donde empezó a construir por primera vez algo sólido por dentro, no solo por fuera. Ese periodo desarrolló su confianza real y las bases de su marca personal. Estuvo en Australia un año y dos meses aproximadamente. Después viajó a Bali y luego solo, durante algo más de un mes, por el sudeste asiático: Camboya (Angkor Wat), Kuala Lumpur, Vietnam, Tailandia (incluida la Gran Barrera de Coral), y de vuelta pasó por Estambul. Se alojaba en hostales con gente de todas las culturas, lo que le ayudó mucho a abrirse a conocer personas distintas.
El giro espiritual
A los 17 años, una novia que canalizaba le hizo pensar por primera vez “aquí hay algo”, aunque el tema quedó aparcado durante años. Antes de arruinarse no rechazaba ni abrazaba la espiritualidad; su madre tenía cierta sensibilidad hacia el tarot. El verdadero punto de inflexión llegó después de arruinarse: una apertura emocional intensa, sensación de amor en el pecho, llanto largo, y la necesidad de pedir perdón a su madre. Esa apertura no la buscó. Vino sola cuando dejó de resistirse a lo que sentía por dentro. Después de esa apertura empezó a percibir sincronicidades espontáneas — como números repetidos en matrículas — sin haberlas buscado mentalmente. A partir de ahí investigó energía, conciencia, psicología racional y subconsciente, y recorrió EMDR, Gestalt, constelaciones familiares, Reiki y kundalini. Hizo una sesión de kundalini que considera que no se debería hacer sin que la consciencia esté preparada — la recuerda como

un ejemplo claro de que no todo lo espiritual es inofensivo si no hay base previa.
Trabajo interior y herramientas que de verdad le movieron
Pasó por terapia, EMDR, Gestalt, constelaciones familiares y mentores — no porque estuviera “acabado”, sino porque quería dejar de repetirse. EMDR: trabajar con una imagen concreta en la mente mientras se repetía el procedimiento, hasta que esa imagen se iba diluyendo. Fue de las primeras pruebas vivenciales que tuvo de que algo invisible se podía mover de forma concreta. Trabajó con una psicóloga del inconsciente que le enseñó un ejercicio que recuerda como el que mejor le fue: cuando aparecía un miedo (por ejemplo, “esta persona me va a dejar”), ella le hacía desgranarlo hasta encontrar 5 o 10 formas concretas en las que su mente estaba leyendo “pruebas” de que iba a ocurrir. Después le hacía buscar, para cada una, la prueba completamente opuesta — y así ir equilibrando el inconsciente. Meditación del niño interior: cerrar los ojos, visualizar al niño que fue y preguntarle qué necesita. Le ayudó mucho con la regulación emocional y a entender sus propias emociones de forma concreta. Estar en silencio 5-10 minutos al día, sin meditar formalmente — simplemente estar. Priming estilo Tony Robbins: gratitud al despertar, cuidado consciente de la música que escucha cuando entra en un proceso importante. Ejercicio físico como herramienta de disciplina y de regulación. Duchas frías durante un tiempo, para entrenar su mente a hacer cosas incómodas. Dejar de depender de que una mujer lo eligiera para sentirse válido cambió por completo cómo se relacionaba con todo lo demás en su vida. Cuando dejó de crear contenido para “demostrar” algo a su padre y a su entorno, todo en su negocio empezó a fluir de otra manera.
Patrones repetidos que reconoce en sí mismo
El patrón de “mañana empiezo”: mañana hago ejercicio, mañana grabo ese vídeo, mañana cambio este hábito — empezar fuerte y abandonar a los pocos días, una y otra vez, hasta que dejó de confiar en su propia palabra. La máscara de ser el más sociable y extrovertido del grupo mientras nadie sabía lo que le pasaba realmente por dentro. Leer decenas de libros de desarrollo personal durante años antes de aplicar nada de verdad — era entretenimiento, no crecimiento. Retrasar el lanzamiento de proyectos durante años por “no estar listo”, cuando en realidad le daba pánico que lo juzgaran. Buscar el curso perfecto, el mentor perfecto, la técnica perfecta — como forma inconsciente de no tener que empezar nunca. Perder tiempo en videojuegos, porno, apuestas y scroll mientras decía que “no tenía tiempo” para trabajar en sí mismo.
Momentos recientes y conversaciones que marcan dónde está hoy
Su madre le dijo recientemente, después de una conversación profunda, algo que le marcó: “Sé que lo sabes, me estás dejando

brutalmente impactada porque sé que lo sabes, pero ¿cómo lo cambio?”. Esa pregunta (“vale, lo entiendes, pero ¿cómo se cambia?”) es la que define el salto que está dando ahora mismo como creador — de divulgar diagnóstico a entregar camino. Está destilando y nombrando las herramientas que ha probado en sí mismo a lo largo de los años para convertirlas en un método propio y transmisible, no para seguir “mezclando” como hasta ahora. Ha definido con claridad su posicionamiento diferenciador: tío práctico que sube a lo invisible (energía, vibración, emociones, inconsciente) solo cuando sirve para resolver algo concreto que al avatar le está pasando en la vida real. Rechaza explícitamente el territorio esotérico abstracto (guías espirituales, niños índigo, kundalini como etiqueta de marca, flotar sin bajar a la vida). Trabaja actualmente también escalando marcas personales de otros dentro del nicho de autoayuda y desarrollo personal. Trabaja con un médium profesional en el que confía genuinamente (le ayudó mucho en su propio pasado) y con quien ha conseguido resultados de facturación muy buenos para él. Nota de uso: no mencionar el nombre del cliente ni ninguna cifra de su facturación en contenido público — es un resultado suyo, no de Abel, y Abel prefiere no compartirlo. Si se quiere usar como prueba de autoridad, enfocarlo siempre desde el lado de Abel (“ayudo a otros a escalar su marca personal”, sin nombres ni números) y pedir autorización explícita caso por caso si se quisiera ser más concreto. Su día a día actual es deliberadamente simple, sin ostentación: rutina, trabajo, gimnasio, introspección, y enfrentarse activamente al miedo a la soledad más extrema — no necesita comprar ni mostrar nada externo para sentir que avanza. Es en sí mismo un contraste fuerte con la época en la que perseguía dinero, físico o reconocimiento como prueba de valor. Combina en su trabajo actual su experiencia con inteligencia artificial (llegó a montar una aplicación propia), sus conocimientos de YouTube, creación de páginas web y marketing digital al servicio de un mensaje, no de demostrar algo.
Otros intentos y proyectos antes de encontrar su camino
Episodios que muestran que probó muchos caminos distintos para ganar dinero antes de que algo encajara de verdad — útiles para desarmar la creencia de “yo no he probado nada” o “me falta encontrar la idea correcta”.
Creó páginas web como una de sus vías de generar ingresos. Probó el dropshipping. Probó aprender y hacer publicidad con Facebook Ads. Probó el trading. Montó una aplicación propia aplicando lo que aprendió de inteligencia artificial.
Cómo elegir el momento adecuado para una pieza
Guía rápida para quien use este catálogo al generar contenido:
Tema de ansiedad o insomnio → 3:40 AM despertándose con el corazón acelerado, “estar espabilado” como eufemismo de ansiedad, 17.000€/mes sin dormir, ataque de ansiedad con 19 años solo en el borde de la cama.

Tema de dinero y vacío → 100.000 suscriptores y seguir sintiéndose un don nadie, viaje a Finlandia a sus padres como logro conseguido mientras por dentro se moría, deuda con Hacienda de 3.000€.
Tema de reinicio y empezar de cero → fregar platos en Brisbane 8 horas por 20 dólares, mes solo por el sudeste asiático en hostales.
Tema de dependencia emocional o pareja → vigilar el WhatsApp de forma obsesiva, relación con la chica atractiva narcisista.
Tema de evasión y vicios → 2.500€ perdidos en una noche apostando a ping-pong, mandos de consola rotos jugando al Call of Duty, 1º y 2º de la ESO.
Tema de infancia e identidad → mudanza de 700 km a los 10 años, bullying en el colegio nuevo, trayecto diario de 40-45 minutos a Castelldans, episodio de ansiedad compartido con la madre en casa.
Tema de “yo también lo intenté todo” (desarmar excusas) → curso Crecetube de 900€, dropshipping, Facebook Ads, trading, dos canales de YouTube anteriores, trabajos en 7-8 oficios distintos antes del éxito.
Tema de apertura espiritual o invisible → la apertura emocional después de arruinarse (amor en el pecho, llanto, pedir perdón a la madre), las sincronicidades posteriores no buscadas (números repetidos en matrículas), la novia que canalizaba a los 17.
Tema de herramientas que funcionaron → el ejercicio de los 510 opuestos con la psicóloga del inconsciente, la meditación del niño interior, confiar en que no se moría durante el ataque de ansiedad.
Tema de “ya no demuestro” → cuando dejó de crear contenido para demostrarle algo a su padre, el día a día actual deliberadamente simple sin ostentación.
Tema de “sé el diagnóstico pero no sé cómo cambiarlo” → la conversación reciente con su madre (“sé que lo sabes, pero cómo lo cambio”) — este momento es el puente perfecto para hablar de la diferencia entre entender y transformar.

---

# ARCHIVO: ANALISIS.md

# Cómo construye Lavri sus vídeos de YouTube (análisis del 11/10/2026)

Canal: youtube.com/@alexlavri · eslogan «contenido que vende». Vídeos transcritos en `audio/`:
- JPiqGW-8bOY «Estoy harta de que os mientan»
- GYIrtQ_uyuQ «Dame 16:10 minutos y jamás tendrás miedo a la crítica»
- 48Qdnh0hrcc «Las 2 únicas maneras de monetizar tus redes»
- voZNfo1Un64 «Tu falta de perfección te llevará a 10k/mes»
- nle5nAM2Lj8 «Así creadores ganan 10.000/mes con 500 views»
- cAdgm1kxZd8 «Por eso perdí 100.000 € haciéndome viral»
- drn8914_2ts «Cómo atraer ventas publicando en redes»
- UqvyD9HBU00 «No puedes darle las sobras de tu energía…»

## La estructura (se repite en todos)
1. **Arranque en los primeros 10 s.** Ataque al mercado o una promesa, hablando de tú.
   - «Vengo a explicarte por qué si sigues buscando visitas… te vas a arruinar.»
   - «Si me concedes 10-15 minutos voy a eliminar tu miedo al hate.»
   - A veces con una anáfora: «Yo nunca fui la más inteligente… y aun así…».
2. **Su credencial en una frase, en presente.** «Por si no me conoces, soy Labri, el mes pasado cerré más de 207.000 €», «no te lo explico para fardar».
3. **Lo que dice el mercado y le cansa.** CRM, setters, closers, viralidad, guiones, micro.
4. **2-3 «puntos» numerados**, que repasa al final. Cada punto lleva:
   - la creencia del cliente entre comillas («Labri, necesito seguidores para vender»);
   - una prueba con un cliente real y su cifra;
   - una colleja («¿Cuál es tu excusa?»).
5. **Metáforas sencillas.** El estadio de fútbol con 90.000 personas y un anuncio de clínicas.
6. **Su pasado SOLO como prueba dentro de un punto.** «Crecí 100.000 en 37 días… cero ventas: viralidad no son clientes.»
7. **Su oferta, natural, a mitad del vídeo.** Cuenta cómo lanza su intensivo y que enseña testimonios, sin vender.
8. **Cierre con su frase de batalla** más el intensivo o el vídeo recomendado.
   - «No busquéis viralidad, buscad conversión y comunidad.»
   - «Si no vives para servir, no sirves para vivir.»

## Títulos de YouTube: siempre en positivo (Abel, 13/10/2026)
«La carátula la ves como algo positivo, como ayuda, como consejo. Ahí está la clave.» Mezcla de motivación y «te enseño a…»; los errores y mentiras van dentro del vídeo.
- «Así atraerás ventas a tu negocio publicando en redes sociales (cópiame)»
- «Dame 16:10 minutos y jamás tendrás miedo a la crítica»
- «Desvelo la "ventaja competitiva" que me genera €230k/mes (cópiame)»
- «Estoy harta de que os mientan (desvelo cómo cerrar €10k/mes con tu marca personal)»
- «Las 2 únicas maneras de monetizar tus redes sociales»
- «Por esto llegar a €10k/mes es "fácil"»

## Tono y producción
- **Tono:** crudo y con tacos («jodidamente», «papanatas», «puta prioridad»), «chicos», «familia».
- **Producción:** graba con el móvil y le da igual el eco: «compito por información, no por edición».
- **Su sistema tiene nombre:** el «ecosistema de contenido», el «triángulo de la venta».
- **Hasta la mentalidad le habla a su cliente:** gente que publica contenido y tiene miedo a los comentarios.

# Sus reels de Instagram (10 últimos, analizados el 12/10/2026)
Vídeos en `reels/`, medidas en `reels/analisis.json`, portadas en `reels/portadas.png`. Herramienta: `herramientas/analizar_reels_ref.py`.
- **Voz:** casi nunca para. Hueco entre palabras con mediana 0 s, el 90 % por debajo de 0,1 s y el máximo en ~0,3 s. Habla a 3,2–4,5 palabras/s (lo normal hablando son ~3). Todos con música debajo.
- **Gancho:** la primera palabra en el segundo 0. Es una frase completa: un resultado, una historia o una afirmación polémica.
- **Cortes de imagen:** la mayoría son un solo plano o pocos; el dinamismo lo da el audio sin aire, no el número de cortes. Los de b-roll llevan muchos más (27–79).
- **Título arriba:**
  - blanco, en negrita, centrado, 2 líneas de 6–9 palabras, justo encima del vídeo;
  - acaba en dos puntos y le da al reel el contexto y la connotación negativa;
  - fórmulas: «Así cierro…», «Por esto…», «Si no haces “yapping” jamás…», «Así fue como un “consejo” casi destroza mi negocio:», «Porqué sin YouTube jamás cerraría 6 cifras/mes:»;
  - números reales (€230k/mes, 45 días, x10) y la palabra clave entre comillas y en cursiva.
- **Subtítulos:** una palabra cada vez, pequeña y discreta sobre el vídeo.

# Banco de títulos de referencia (Rebeca y Lavri, 12/10/2026)
Títulos de REELS (los de YouTube, arriba, van en positivo). Abel: «los que tengan franja negra, siempre mejor». Se usan para copiar la ESTRUCTURA, nunca el título; siempre adaptados a su mensaje y con connotación negativa.
- **Rebeca (franja negra):**
  - «No vendas espiritualidad con tu Marca Personal:»
  - «Si no sabes en qué eres bueno, olvídate de crear Marca Personal auténtica:»
  - «El contenido de conexión es el que MÁS vende (mentoría con clienta):»
  - «Una buena comunicación en tu contenido: Atrae, Conecta y vende»
  - «Qué importante es tener gente en tu entorno que ha visto todas tus versiones y siguen ahí:»
  - «Un poquito de mí:»
- **Rebeca (otros):**
  - «NO me compres sin ver antes todo mi contenido:»
  - «Esto hará un x10 en la entrega de tu servicio:»
  - «El secreto de un buen contenido para tu Marca Personal:»
  - «Hasta ciertos millonarios tienen este miedo inconsciente:»
  - «Este es mi motivo real:»
- **Lavri (franja negra):**
  - «$70.000 en 45 días con menos de 10k seguidores:»
  - «Así “trato” a mis clientas cuando vienen a grabar conmigo:»
  - «Porqué sin YouTube jamás cerraría 6 cifras/mes:»
  - «Porqué publicar a Volumen hará un x10 en tus ventas:»
  - «Si no haces “yapping” jamás crearás contenido real:»
  - «Así fue como un “consejo” casi destroza mi negocio:»
  - «La mentalidad que me ha llevado a €230k/mes»
  - «Una venta interrumpe el Onboarding con Clienta (épico):»
  - «Así cierro ventas de €20k sin llamadas de venta:»
  - «Por esto escalé a €150k/mes sin Setters ni Closers:»
  - «No existen países “caros” sino poder adquisitivo bajo:»
  - «Por esto “copiar contenido” no te hace vender más:»
  - «Así crecería 10.000 seguidores en 30 días (desde cero):»
  - «Si no haces esto jamás crecerás a 100.000 seguidores:»
- **Estructuras que salen:**
  - «No [hagas] X con tu marca:»
  - «Si no X, olvídate de Y:»
  - «Hasta [quien menos piensas] tiene este [error/miedo]:»
  - «No existe X, sino Y:»
  - «Así fue como X casi destroza Y:»
  - «Por esto “X” no te hace Y:»
  - «Esto hará/te quita…:»
  - «El secreto de…:»
  - cifra + contexto
  - (paréntesis al final)
